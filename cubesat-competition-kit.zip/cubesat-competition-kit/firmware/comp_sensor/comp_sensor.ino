// =====================================================================
//  comp_sensor.ino  -  CubeSat sensor competition, 2 x LDR angle sensor
//  ESP32-S3 (SunSeek v1.3).  Arduino core 2.x/3.x.
//
//  Libraries: Adafruit SSD1306, Adafruit GFX   (Library Manager)
//
//  Two modes, toggled by the BOOT button or by "MODE RUN" / "MODE RAW":
//    RAW  - streams telemetry for comp_gui.py, OLED shows the raw numbers
//    RUN  - OLED shows the estimated angle.  This is the competition mode.
//
//  The maths here is character-for-character the same as comp_gui.py:
//
//      R      = R_F * (VREF/V - 1)
//      G      = 1/R                       conductance
//      E      = (G - G_dark)^(1/gamma)    proportional to irradiance
//      L      = ln(E_A) - ln(E_B) - lnk   monotone in angle, unbounded
//      angle  = table lookup on L         rows evenly spaced in L
//
//  Outside the ratio zone - where one cell is geometrically dark and L has
//  saturated - the firmware falls back to the AMPLITUDE of the cell that is
//  still lit, which is out on the shoulder of its cosine and therefore very
//  steep in angle. That branch is not brightness-immune, so while the reading
//  is in the ratio zone the firmware continuously re-references brightness
//  from ln(E_A + E_B) against the calibrated CAL_SUM table, and carries that
//  reference into the ends. Readings from this branch are flagged "amp".
//
//  Because the table is built on L, every multiplicative constant above
//  (R_F, VREF, gamma, k) is just an offset in L and is absorbed by the
//  calibration.  Only G_dark has to be right - it is subtracted, not
//  divided out.
// =====================================================================

#include <Arduino.h>
#include <math.h>
#include <Wire.h>
#include <WiFi.h>
#include <Preferences.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include "config.h"
#include "calib.h"

// A calib.h generated before per-cell darkness thresholds existed defines only
// CAL_E_EDGE. Keep it building - but regenerate it, because one shared
// threshold is exactly what stops the outer sectors working when the two cells
// have different stray-light floors.
#ifndef CAL_E_EDGE_A
#define CAL_E_EDGE_A CAL_E_EDGE
#endif
#ifndef CAL_E_EDGE_B
#define CAL_E_EDGE_B CAL_E_EDGE
#endif

#define FW_VERSION "1.2.0"

static Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
static bool  oledOK   = false;
static int   mode     = DEFAULT_MODE;      // 0 RAW, 1 RUN
static int   avgN     = DEFAULT_AVG;
static int   rateHz   = DEFAULT_RATE;
static float smoothA  = DEFAULT_SMOOTH;
static bool  holdOn   = false;

static float Lsm = NAN;                    // smoothed L, display only
static uint32_t tNext = 0;

// status codes
enum { ST_OK = 0, ST_EDGE_LO, ST_EDGE_HI, ST_NOSRC, ST_NOCAL, ST_AMP };
static const char *ST_NAME[] = { "ok", "edge-", "edge+", "no source", "no cal", "amp" };
// ---------------------------------------------------------------------
// The brightness reference.
//
// Outside the ratio zone there is one measurement and two unknowns - angle
// and how bright the source is - so the angle is only as good as this number.
// It can ONLY be learned inside the ratio zone, and a reading taken at an end
// with a cold reference is wrong by however far the source is from the
// brightness it was calibrated at: at 0.44x, that is 21 degrees.
//
// Three things protect it:
//   1. it survives a power cycle, in NVS
//   2. its age is reported, so a stale one is visible
//   3. the OLED says REF COLD instead of showing a confident wrong number
// ---------------------------------------------------------------------
static float    ampRef = 0.0f;       // ln brightness offset vs calibration
static bool     ampRefValid = false;
static uint32_t ampRefAt = 0;        // millis() of the last update
static float    ampRefSaved = NAN;   // what is in NVS right now
static uint32_t ampRefSaveAt = 0;
#define AMP_ALPHA 0.02f              // how fast the brightness reference tracks
#define AMP_SAVE_DELTA 0.02f         // write NVS only past this much drift
#define AMP_SAVE_MS    30000UL       // ...and at most this often
static Preferences prefs;

static void ampRefStore(bool force) {
  if (!ampRefValid) return;
  uint32_t now = millis();
  if (!force) {
    if (ampRefSaved == ampRefSaved && fabsf(ampRef - ampRefSaved) < AMP_SAVE_DELTA)
      return;
    if (now - ampRefSaveAt < AMP_SAVE_MS) return;
  }
  prefs.putFloat("ampRef", ampRef);
  prefs.putString("cal", CAL_LABEL);
  ampRefSaved = ampRef;
  ampRefSaveAt = now;
}

// ---------------------------------------------------------------------
// sampling
// ---------------------------------------------------------------------
static float readAvg_mV(int pin, int n) {
  uint32_t acc = 0;
  for (int i = 0; i < n; i++) acc += analogReadMilliVolts(pin);
  return (float)acc / (float)n;
}

static inline float conductance(float v_mV, float rf, float vref) {
  if (v_mV < 0.001f) v_mV = 0.001f;
  if (v_mV > vref - 0.001f) v_mV = vref - 0.001f;
  float r = rf * (vref / v_mV - 1.0f);
  if (r < 1e-6f) r = 1e-6f;
  return 1.0f / r;
}

static inline float irradiance(float v_mV, float rf, float vref,
                               float gdark, float gamma) {
  float g = conductance(v_mV, rf, vref) - gdark;
  if (g < 1e-12f) g = 1e-12f;
  return powf(g, 1.0f / gamma);
}

// ---------------------------------------------------------------------
// table lookup - rows are evenly spaced in L, so no search is needed
// ---------------------------------------------------------------------
static float lutAngle(float L, float *sigma_out, int *status) {
  if (CAL_N < 2) { *sigma_out = 0.0f; *status = ST_NOCAL; return NAN; }
  float x = (L - CAL_L0) / CAL_DL;
  *status = ST_OK;
  if (x < 0.0f)            { x = 0.0f;            *status = ST_EDGE_LO; }
  if (x > (float)(CAL_N-1)){ x = (float)(CAL_N-1);*status = ST_EDGE_HI; }
  int i = (int)floorf(x);
  if (i > CAL_N - 2) i = CAL_N - 2;
  if (i < 0) i = 0;
  float f = x - (float)i;
  *sigma_out = CAL_SIGMA[i] + f * (CAL_SIGMA[i + 1] - CAL_SIGMA[i]);
  return CAL_THETA[i] + f * (CAL_THETA[i + 1] - CAL_THETA[i]);
}

// expected ln(E_A+E_B) for a reading that landed at table position x
static float lutSum(float L) {
  float x = (L - CAL_L0) / CAL_DL;
  if (x < 0.0f) x = 0.0f;
  if (x > (float)(CAL_N-1)) x = (float)(CAL_N-1);
  int i = (int)floorf(x);
  if (i > CAL_N - 2) i = CAL_N - 2;
  if (i < 0) i = 0;
  float f = x - (float)i;
  return CAL_SUM[i] + f * (CAL_SUM[i + 1] - CAL_SUM[i]);
}

// amplitude branch: one lit cell, evenly spaced in ln(E)
static float ampAngle(float x, float x0, float dx, const float *tab, int n,
                      bool *clipped) {
  float u = (x - x0) / dx;
  *clipped = false;
  if (u < 0.0f)          { u = 0.0f;          *clipped = true; }
  if (u > (float)(n-1))  { u = (float)(n-1);  *clipped = true; }
  int i = (int)floorf(u);
  if (i > n - 2) i = n - 2;
  if (i < 0) i = 0;
  float f = u - (float)i;
  return tab[i] + f * (tab[i + 1] - tab[i]);
}

// ---------------------------------------------------------------------
// one measurement       (struct Meas is declared in config.h - see the
// comment there for why it cannot live in this file)
// ---------------------------------------------------------------------
static Meas measure() {
  Meas m;
  m.vA = readAvg_mV(PIN_LDR_A, avgN);
  m.vB = readAvg_mV(PIN_LDR_B, avgN);
  m.eA = irradiance(m.vA, CAL_RF_A, CAL_VREF_MV, CAL_GD_A, CAL_GAMMA_A);
  m.eB = irradiance(m.vB, CAL_RF_B, CAL_VREF_MV, CAL_GD_B, CAL_GAMMA_B);
  m.L  = logf(m.eA) - logf(m.eB) - CAL_LNK;
  m.D  = tanhf(m.L * 0.5f);

  if (isnan(Lsm)) Lsm = m.L;
  else            Lsm = Lsm + (1.0f - smoothA) * (m.L - Lsm);
  float Ldisp = (smoothA > 0.0f) ? Lsm : m.L;

  m.angle = lutAngle(Ldisp, &m.sigma, &m.status);

  // Two independent things can disqualify the ratio answer, and BOTH have to
  // be checked - each one catches cases the other misses.
  //
  //  1. A cell has gone dark.  Once a cell drops to its stray-light floor, L
  //     FOLDS BACK into the table's own range and reads as a perfectly valid
  //     angle, so a range test never sees it.  Each cell gets its own
  //     threshold: two LDRs on the same deck routinely sit an order of
  //     magnitude apart in stray light, and one shared number is then either
  //     above one cell's floor or below the other's.
  //  2. L ran off the end of the table.  Both cells can still be lit while L
  //     is past the last calibrated row - that is the handover region - and a
  //     clamped lookup would report the end of the table forever.
  //
  // Thresholds ride with the LED: at twice the calibration brightness a dark
  // cell's stray-light floor is twice as high too.
  float amp1    = ampRefValid ? expf(ampRef) : 1.0f;
  bool  bothLit = (m.eA > CAL_E_EDGE_A * amp1) && (m.eB > CAL_E_EDGE_B * amp1);
  bool  ratioOK = (m.status == ST_OK) && bothLit;

  if (ratioOK) {
    // brightness-immune answer - use it to learn how far the LED has drifted
    float S = logf(m.eA + m.eB);
    float err = S - lutSum(Ldisp);
    if (!ampRefValid) { ampRef = err; ampRefValid = true; }
    else              { ampRef += AMP_ALPHA * (err - ampRef); }
    ampRefAt = millis();
    ampRefStore(false);
  } else if (CAL_N >= 2) {
    // the ratio is not usable here: read the level of the brighter cell
    int lit = (m.eA >= m.eB) ? 0 : 1;
    int n = 0; float x0 = 0, dx = 1; const float *tab = NULL;
    if (CAL_AL_N >= 2 && CAL_AL_CH == lit) {
      n = CAL_AL_N; x0 = CAL_AL_X0; dx = CAL_AL_DX; tab = CAL_AL_TH;
    } else if (CAL_AH_N >= 2 && CAL_AH_CH == lit) {
      n = CAL_AH_N; x0 = CAL_AH_X0; dx = CAL_AH_DX; tab = CAL_AH_TH;
    }
    if (n >= 2) {
      float x = logf(lit ? m.eB : m.eA) - ampRef;
      bool clipped;
      m.angle = ampAngle(x, x0, dx, tab, n, &clipped);
      m.sigma = NAN;
      m.status = clipped ? (lit ? ST_EDGE_HI : ST_EDGE_LO) : ST_AMP;
    } else {
      m.status = (m.eA >= m.eB) ? ST_EDGE_LO : ST_EDGE_HI;
    }
  }

  if (m.status != ST_NOCAL && (m.eA + m.eB) < CAL_MIN_E) m.status = ST_NOSRC;
  return m;
}

// ---------------------------------------------------------------------
// OLED
// ---------------------------------------------------------------------
static bool i2cProbe(uint8_t sda, uint8_t scl, uint8_t addr) {
  Wire.end();
  Wire.begin(sda, scl, 400000);
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}

static void oledInit() {
  uint8_t addrs[2] = { 0x3C, 0x3D };
#if OLED_AUTOSCAN
  int n = sizeof(OLED_TRY_SDA) / sizeof(OLED_TRY_SDA[0]);
  for (int i = 0; i < n && !oledOK; i++) {
    for (int a = 0; a < 2 && !oledOK; a++) {
      if (i2cProbe(OLED_TRY_SDA[i], OLED_TRY_SCL[i], addrs[a])) {
        if (oled.begin(SSD1306_SWITCHCAPVCC, addrs[a])) {
          oledOK = true;
          Serial.printf("# OLED at SDA=%u SCL=%u addr=0x%02X\n",
                        OLED_TRY_SDA[i], OLED_TRY_SCL[i], addrs[a]);
        }
      }
    }
  }
#else
  for (int a = 0; a < 2 && !oledOK; a++) {
    if (i2cProbe(OLED_SDA, OLED_SCL, addrs[a]) &&
        oled.begin(SSD1306_SWITCHCAPVCC, addrs[a])) oledOK = true;
  }
#endif
  if (!oledOK) Serial.println("# OLED not found - serial only");
}

static void drawRun(const Meas &m) {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);

  if (m.status == ST_NOCAL) {
    oled.setTextSize(2);
    oled.setCursor(6, 10);  oled.print("NO CAL");
    oled.setTextSize(1);
    oled.setCursor(0, 34);  oled.print("paste calib.h and");
    oled.setCursor(0, 44);  oled.print("re-upload");
    oled.setCursor(0, 56);  oled.printf("A%4.0f B%4.0f mV", m.vA, m.vB);
    oled.display();
    return;
  }
  if (m.status == ST_NOSRC) {
    oled.setTextSize(2);
    oled.setCursor(2, 16);  oled.print("NO SOURCE");
    oled.setTextSize(1);
    oled.setCursor(0, 44);  oled.printf("A%4.0f  B%4.0f mV", m.vA, m.vB);
    oled.setCursor(0, 56);  oled.print("LED off / blocked");
    oled.display();
    return;
  }

  // A level-branch reading is only as good as the brightness reference. If we
  // have never been in the ratio zone, say so loudly instead of printing a
  // confident number that can be tens of degrees out.
  bool onLevel = (m.status == ST_AMP || m.status == ST_EDGE_LO ||
                  m.status == ST_EDGE_HI);
  bool refCold = onLevel && !ampRefValid;

  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.print(refCold ? "ANGLE ?" : "ANGLE");
  oled.setCursor(90, 0);
  oled.print(m.status == ST_OK   ? "   ok"
           : m.status == ST_AMP  ? (refCold ? " amp?" : "  amp")
           : m.status == ST_EDGE_LO ? "edge-" : "edge+");

  oled.setTextSize(3);
  oled.setCursor(2, 14);
  oled.printf("%6.1f", m.angle);
  oled.setTextSize(1);
  oled.setCursor(112, 16);
  oled.print("deg");

  oled.setCursor(0, 40);
  if (refCold)         oled.print("REF COLD - swing thru");
  else if (onLevel)    oled.printf("level  ref%+5.2f %2lus",
                                   ampRef, (unsigned long)((millis() - ampRefAt) / 1000));
  else                 oled.printf("+/-%5.2f  D%+6.3f", m.sigma, m.D);

  // position bar, CAL_ANG_MIN .. CAL_ANG_MAX
  int x0 = 0, x1 = 127, y = 54;
  oled.drawRect(x0, y, x1 - x0 + 1, 9, SSD1306_WHITE);
  float f = (m.angle - CAL_ANG_MIN) / (CAL_ANG_MAX - CAL_ANG_MIN);
  if (f < 0) f = 0;
  if (f > 1) f = 1;
  int px = x0 + 2 + (int)(f * (x1 - x0 - 4));
  oled.fillRect(px - 1, y + 2, 3, 5, SSD1306_WHITE);
  oled.drawFastVLine((x0 + x1) / 2, y + 1, 7, SSD1306_WHITE);
  if (holdOn) { oled.setCursor(56, 40); oled.print("HOLD"); }
  oled.display();
}

static void drawRaw(const Meas &m) {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);   oled.print("RAW - collecting");
  oled.setCursor(0, 12);  oled.printf("V  A %6.1f mV", m.vA);
  oled.setCursor(0, 22);  oled.printf("V  B %6.1f mV", m.vB);
  oled.setCursor(0, 34);  oled.printf("L  %+8.4f", m.L);
  oled.setCursor(0, 44);  oled.printf("D  %+8.4f", m.D);
  oled.setCursor(0, 56);
  if (CAL_N >= 2) oled.printf("cal: %s", CAL_LABEL);
  else            oled.print("cal: none");
  oled.display();
}

// ---------------------------------------------------------------------
// serial commands
// ---------------------------------------------------------------------
static void handleCommand(String s) {
  s.trim();
  if (!s.length()) return;
  String up = s;
  up.toUpperCase();

  if (up == "ID") {
    Serial.printf("ID,comp_sensor,%s,cal=%s,n=%d,amp=%d/%d,ok\n",
                  FW_VERSION, CAL_LABEL, (int)CAL_N, (int)CAL_AL_N, (int)CAL_AH_N);
  } else if (up == "HELP" || up == "?") {
    Serial.println("# ID | MODE RAW|RUN | RATE <hz> | AVG <n> | SMOOTH <0..0.9> | GET | HOLD 0|1");
    Serial.println("# REF | REF CLEAR | REF SET <ln> - the brightness reference the ends depend on");
  } else if (up == "GET") {
    Serial.printf("# mode=%s avg=%d rate=%d smooth=%.2f oled=%s\n",
                  mode ? "RUN" : "RAW", avgN, rateHz, smoothA, oledOK ? "yes" : "no");
    Serial.printf("# cal=%s n=%d L0=%.6f dL=%.6f lnk=%.6f gdA=%.6g gdB=%.6g\n",
                  CAL_LABEL, (int)CAL_N, CAL_L0, CAL_DL, CAL_LNK, CAL_GD_A, CAL_GD_B);
    Serial.printf("# amp lo n=%d ch=%d  hi n=%d ch=%d  ampRef=%.4f %s\n",
                  (int)CAL_AL_N, (int)CAL_AL_CH, (int)CAL_AH_N, (int)CAL_AH_CH,
                  ampRef, ampRefValid ? "(tracking)" : "(COLD - ends unreliable)");
    Serial.printf("# dark thresholds  A=%.4g B=%.4g  (x%.3f for brightness)\n",
                  CAL_E_EDGE_A, CAL_E_EDGE_B,
                  ampRefValid ? expf(ampRef) : 1.0f);
  } else if (up.startsWith("MODE")) {
    mode = up.indexOf("RUN") > 0 ? 1 : 0;
    Serial.printf("# mode=%s\n", mode ? "RUN" : "RAW");
  } else if (up.startsWith("RATE")) {
    rateHz = constrain((int)s.substring(4).toInt(), 1, 100);
    Serial.printf("# rate=%d\n", rateHz);
  } else if (up.startsWith("AVG")) {
    avgN = constrain((int)s.substring(3).toInt(), 1, 1024);
    Serial.printf("# avg=%d\n", avgN);
  } else if (up.startsWith("SMOOTH")) {
    smoothA = constrain(s.substring(6).toFloat(), 0.0f, 0.95f);
    Serial.printf("# smooth=%.2f\n", smoothA);
  } else if (up == "AMPRESET" || up == "REF CLEAR") {
    ampRefValid = false; ampRef = 0.0f; ampRefSaved = NAN;
    prefs.remove("ampRef"); prefs.remove("cal");
    Serial.println("# brightness reference cleared, in RAM and in flash");
  } else if (up == "REF") {
    if (!ampRefValid) {
      Serial.println("# ref COLD - no end reading can be trusted. Put the source "
                     "anywhere in the ratio zone for 3 s.");
    } else {
      Serial.printf("# ref ampRef=%+.4f  (source is x%.3f of calibration "
                    "brightness)  age %lus\n",
                    ampRef, expf(ampRef),
                    (unsigned long)((millis() - ampRefAt) / 1000));
    }
  } else if (up.startsWith("REF SET")) {
    ampRef = s.substring(7).toFloat();
    ampRefValid = true; ampRefAt = millis();
    ampRefStore(true);
    Serial.printf("# ref forced to %+.4f\n", ampRef);
  } else if (up.startsWith("HOLD")) {
    holdOn = s.substring(4).toInt() != 0;
    Serial.printf("# hold=%d\n", holdOn ? 1 : 0);
  } else {
    Serial.printf("# unknown: %s\n", s.c_str());
  }
}

// ---------------------------------------------------------------------
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(300);

  // ADC2 is shared with the radio.  Both off, for good.
  WiFi.mode(WIFI_OFF);
  WiFi.disconnect(true);
#if defined(SOC_BT_SUPPORTED) && SOC_BT_SUPPORTED
  btStop();
#endif

  analogReadResolution(ADC_BITS);
  // ADC_11db is the name that exists in every ESP32 Arduino core to date.
  // Core 3.x added ADC_ATTEN_DB_12 as the preferred spelling for the same
  // hardware setting, but not in every 3.x point release - and because these
  // are enum constants, not macros, there is no #ifdef that can pick between
  // them. If some future core ever drops ADC_11db, the setting is index 3:
  //     analogSetPinAttenuation(PIN_LDR_A, (adc_attenuation_t)3);
  analogSetPinAttenuation(PIN_LDR_A, ADC_11db);
  analogSetPinAttenuation(PIN_LDR_B, ADC_11db);

#ifdef BTN_MODE
  pinMode(BTN_MODE, INPUT_PULLUP);
#endif
#ifdef BTN_HOLD
  pinMode(BTN_HOLD, INPUT_PULLUP);
#endif

  Serial.printf("# comp_sensor %s  A=io%d B=io%d  cal=\"%s\" n=%d\n",
                FW_VERSION, PIN_LDR_A, PIN_LDR_B, CAL_LABEL, (int)CAL_N);
  // Restore the brightness reference, but only if it was learned against THIS
  // calibration - a reference from another head's calib.h is worse than none.
  prefs.begin("sunseek", false);
  if (prefs.getString("cal", "") == String(CAL_LABEL) && prefs.isKey("ampRef")) {
    ampRef = prefs.getFloat("ampRef", 0.0f);
    ampRefSaved = ampRef;
    ampRefValid = true;
    ampRefAt = millis();
    Serial.printf("# brightness reference restored: ampRef=%+.4f (x%.3f)\n",
                  ampRef, expf(ampRef));
  } else {
    Serial.println("# no stored brightness reference - swing the source through "
                   "the middle before trusting an end reading");
  }

  oledInit();
  if (CAL_N >= 2) mode = 1;              // calibrated -> straight to RUN
  Serial.println("# OK,ready   (type HELP)");
}

void loop() {
  static String rx;
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') { handleCommand(rx); rx = ""; }
    else if (rx.length() < 120)  rx += c;
  }

#ifdef BTN_MODE
  static uint32_t tBtn = 0;
  if (digitalRead(BTN_MODE) == LOW && millis() - tBtn > 400) {
    tBtn = millis();
    mode = !mode;
    Serial.printf("# mode=%s\n", mode ? "RUN" : "RAW");
  }
#endif
#ifdef BTN_HOLD
  holdOn = (digitalRead(BTN_HOLD) == LOW);
#endif

  uint32_t period = 1000UL / (uint32_t)max(1, rateHz);
  if (millis() < tNext) return;
  tNext = millis() + period;

  static Meas held;
  static bool haveHeld = false;
  Meas m = measure();
  if (holdOn && haveHeld) m.angle = held.angle;
  else { held = m; haveHeld = true; }

  Serial.printf("T,%lu,%.1f,%.1f,%+.4f,%+.4f,%.2f,%.2f,%s\n",
                (unsigned long)millis(), m.vA, m.vB, m.L, m.D,
                isnan(m.angle) ? 0.0f : m.angle, m.sigma, ST_NAME[m.status]);

  if (oledOK) {
    static uint32_t tDraw = 0;
    if (millis() - tDraw > 100) {          // OLED at 10 Hz, it is slow
      tDraw = millis();
      if (mode) drawRun(m); else drawRaw(m);
    }
  }
}
