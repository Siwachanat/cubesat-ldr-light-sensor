// =====================================================================
//  calib.h  -  the ONLY file you edit on competition day.
//
//  Easiest: in comp_gui.py press "Save calib.h" and overwrite this whole
//  file, then re-upload. It writes a complete header, #pragma once and all.
//
//  By hand: press "Copy" (which copies the C block only, never the fit
//  summary above it) and replace everything between the two dashed lines.
//
//  Shipping with CAL_N 0 means "not calibrated yet": the firmware stays in
//  RAW mode and the OLED says NO CAL.
// =====================================================================
#pragma once

/* ---------- calib.h : generated (placeholder) ---------- */
#define CAL_LABEL     "not calibrated"
#define CAL_VREF_MV   3300.0f
#define CAL_RF_A      8200.0f
#define CAL_RF_B      8200.0f
#define CAL_GD_A      0.0f
#define CAL_GD_B      0.0f
#define CAL_GAMMA_A   0.70f
#define CAL_GAMMA_B   0.70f
#define CAL_LNK       0.0f
#define CAL_L0        -1.0f
#define CAL_DL        1.0f
#define CAL_N         0
#define CAL_L1         1.0f
#define CAL_SIGMA_L   0.005f
#define CAL_MIN_E     0.0f
#define CAL_ANG_MIN   0.0f
#define CAL_ANG_MAX   180.0f
#define CAL_E_EDGE    0.0f
static const float CAL_THETA[1] = { 0.0f };
static const float CAL_SIGMA[1] = { 0.0f };
static const float CAL_SUM[1] = { 0.0f };
#define CAL_AL_N      0
#define CAL_AL_CH     0
#define CAL_AL_X0     0.0f
#define CAL_AL_DX     1.0f
static const float CAL_AL_TH[1] = { 0.0f };
#define CAL_AH_N      0
#define CAL_AH_CH     0
#define CAL_AH_X0     0.0f
#define CAL_AH_DX     1.0f
static const float CAL_AH_TH[1] = { 0.0f };
/* ------------------------------------------------------- */
