// =====================================================================
//  config.h  -  hardware map.  Edit this, not the .ino.
//  Board: SunSeek v1.3, ESP32-S3-WROOM-1
// =====================================================================
#pragma once

// ---- LDR inputs -----------------------------------------------------
// io17 / io16 on the S3 are ADC2_CH6 / ADC2_CH5.  ADC2 is shared with the
// radio, so Wi-Fi and Bluetooth MUST stay off or the reads return noise.
// The firmware disables both in setup(); do not re-enable them.
#define PIN_LDR_A      17      // "left"  cell  - the one facing the 0 deg end
#define PIN_LDR_B      16      // "right" cell  - the one facing the 180 deg end

// ---- OLED -----------------------------------------------------------
// If you know the pins, set them here and set OLED_AUTOSCAN 0.
// Otherwise leave the scan on: the firmware tries each pair below and
// prints which one answered.
#define OLED_AUTOSCAN  1
#define OLED_SDA       8
#define OLED_SCL       9
#define OLED_W         128
#define OLED_H         64
static const uint8_t OLED_TRY_SDA[] = { 8, 4, 21, 41, 1, 5 };
static const uint8_t OLED_TRY_SCL[] = { 9, 5, 22, 42, 2, 6 };

// ---- buttons (optional - comment out if the board has none) ---------
#define BTN_MODE       0       // BOOT button: short press toggles RAW / RUN
//#define BTN_HOLD     12      // freeze the displayed angle while held

// ---- sampling -------------------------------------------------------
#define ADC_BITS       12
#define DEFAULT_AVG    64      // ADC reads averaged into one telemetry sample
#define DEFAULT_RATE   20      // telemetry lines per second
#define DEFAULT_SMOOTH 0.25f   // 0 = no smoothing, 1 = frozen.  Display only.
#define SERIAL_BAUD    115200

// ---- one measurement ------------------------------------------------
// This struct lives here, not in the .ino, on purpose.  The Arduino IDE
// auto-generates prototypes for every function in a .ino and inserts them
// ABOVE the sketch body, so a function that returns a type declared in the
// .ino fails to compile with
//     error: 'Meas' does not name a type
// Declaring it in a header the sketch includes makes the type visible to
// those generated prototypes.
struct Meas {
  float vA, vB, eA, eB, L, D, angle, sigma;
  int status;
};

// ---- start-up mode --------------------------------------------------
// 0 = RAW  (stream for the GUI, OLED shows raw numbers)
// 1 = RUN  (OLED shows the estimated angle)
// With a calibration loaded the firmware starts in RUN automatically.
#define DEFAULT_MODE   0
