# Firmware — build it either way

One set of sources, two toolchains. `platformio.ini` sets `src_dir =
comp_sensor`, so PlatformIO compiles the same files the Arduino IDE opens.
There is no second copy to keep in sync, and no way to flash a stale one.

```
firmware/
  platformio.ini          VS Code / PlatformIO project lives here
  comp_sensor/
    comp_sensor.ino       the sketch - Arduino IDE opens this
    config.h              pins, sampling, struct Meas
    calib.h               the ONLY file you edit on the day
```

## Arduino IDE

1. Boards Manager → **esp32 by Espressif Systems**.
2. Library Manager → **Adafruit SSD1306** and **Adafruit GFX Library**.
3. Open `comp_sensor/comp_sensor.ino`.
4. Tools → Board → **ESP32S3 Dev Module**.
5. Tools → **USB CDC On Boot**: *Disabled* for the UART bridge port,
   *Enabled* for the S3's native USB port. If the port opens but the banner
   never prints, it is this.
6. Upload, then Serial Monitor at **115200**.

## VS Code + PlatformIO

1. Install the PlatformIO IDE extension.
2. **Open the `firmware/` folder** (not `comp_sensor/`, not the kit root).
3. Pick the environment in the status bar:
   - `esp32s3_uart` — the CP210x/CH340 bridge. Default, and what the sweep
     rig used.
   - `esp32s3_usb` — the S3's native USB, sets `ARDUINO_USB_CDC_ON_BOOT=1`.
4. Build (✓), Upload (→), Monitor (🔌). Libraries download on first build.

The env choice is the same decision as the IDE's "USB CDC On Boot" menu.
Same board, same sketch — only how `Serial` is routed differs.

## Either way, first boot should say

```
# comp_sensor 1.0.0  A=io17 B=io16  cal="not calibrated" n=0
# OLED at SDA=8 SCL=9 addr=0x3C
# OK,ready   (type HELP)
```

and the OLED shows **NO CAL**. That is correct for an uncalibrated board —
paste the block from `comp_gui.py` into `calib.h` and re-upload, and it boots
straight into RUN mode.

## Checking a change without either IDE

```
python3 ../tests/check_compile.py
```

Compiles the sketch the way the Arduino IDE does — prototypes hoisted above
the body — against minimal Arduino stubs, and fails on any warning. It also
checks that `platformio.ini` still points at `comp_sensor`, so the two build
paths cannot quietly diverge. It does not exercise the ESP32 toolchain; only a
real build does that.

## What changed in 1.1.0 — and why the ends used to clamp

Two bugs conspired to pin every reading past the ratio zone at the end of the
table, which is what "precise only from 45 to 135°" looked like.

1. **`measure()` only tried the level branch when a cell was dark.** Both cells
   can still be lit while `L` has run off the end of the table — that is the
   handover region, and every angle beyond it — and the clamped lookup was
   returned unchallenged. The ratio answer is now kept only when the lookup
   was in range **and** both cells are lit; anything else falls through.
2. **One darkness threshold for two cells.** On a real deck the two LDRs sit at
   very different stray-light floors — 6.7e-10 and 7.3e-09 on the measured
   head, a factor of eleven — so a single `CAL_E_EDGE` lands above one cell's
   floor and below the other's. The cell with the higher floor was never seen
   to go dark, so its half of the arc never reached the level table.
   `calib.h` now carries `CAL_E_EDGE_A` and `CAL_E_EDGE_B`.

An old `calib.h` still compiles: both names fall back to `CAL_E_EDGE`. It will
still get the ends wrong, so regenerate it.

## Which protractor scale is this calibration on?

The firmware has no opinion. `CAL_THETA[]` carries whatever angles you typed
during the sweep, and the OLED prints them back — so a sweep entered as
0..180 gives a board that reads 0..180, and one entered as -90..+90 gives a
board that reads -90..+90. There is no offset constant to set and none to get
wrong.

To move an existing sweep or an existing `calib.h` onto a differently-zeroed
protractor, use `rezero.py` in the kit root (or the **Re-zero** button in the
GUI's points panel):

```
python3 rezero.py -90 data/my_sweep.csv firmware/comp_sensor/calib.h
```

It touches four things and nothing else: `CAL_THETA[]`, `CAL_AL_TH[]`,
`CAL_AH_TH[]`, and `CAL_ANG_MIN`/`CAL_ANG_MAX`. Everything else in the header
is in units of `ln E` or `L` and does not know where the protractor's zero is.
`tests/check_rezero.py` proves that: it fits, re-zeros, refits, and checks
every other value comes out bit-identical.

## Two version traps already hit

- **`struct Meas` lives in `config.h`, not in the .ino.** Both toolchains hoist
  generated prototypes above the sketch body, so a type declared in the .ino is
  not yet visible to them. Any new type used in a function signature goes in a
  header.
- **ADC attenuation is written `ADC_11db`.** Core 3.x added `ADC_ATTEN_DB_12`
  for the same setting, but not in every point release, and enum constants
  cannot be tested with `#ifdef`. The universal spelling is the one that
  builds everywhere.
