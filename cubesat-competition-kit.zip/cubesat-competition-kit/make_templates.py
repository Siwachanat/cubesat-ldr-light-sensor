#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1:1 cutting templates for the CENTRE BLADE.

The competition head has the two LDRs already mounted, splayed about 20 deg
outward.  The blade between them is the only part we design, so that is the
only part on these sheets.

    python make_templates.py            -> baffle_templates.pdf

Print at 100% / "actual size".  Every sheet carries a 100 mm check bar.
"""
import math

from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas

OUT = "baffle_templates.pdf"

BETA = 20.0            # splay per side, fixed by the organisers
W_CELL = 4.3           # LXD5528A window width
BLADE_Z = 30.0         # blade height in Z - tall, so the shadow edge holds
BLADE_D = 26.0         # blade depth, datum to back edge
TAB = 4.0              # fold tab that hugs the dome and closes the gap
TRIMS = [1.0, 1.5, 2.0, 3.0, 4.0, 6.0]      # proud-height trim ladder

CUT = colors.black
FOLD = colors.HexColor("#0b6fb8")
DATUM = colors.HexColor("#c1440e")
NOTE = colors.HexColor("#666666")


def hdr(c, page, title, sub=""):
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(15 * mm, page[1] - 14 * mm, title)
    if sub:
        c.setFont("Helvetica", 8.5)
        c.setFillColor(NOTE)
        t = c.beginText(15 * mm, page[1] - 19 * mm)
        for line in sub.split("\n"):
            t.textLine(line)
        c.drawText(t)
    c.setFillColor(colors.black)


def scalebar(c, x, y):
    c.setStrokeColor(colors.black)
    c.setDash()
    c.setLineWidth(0.8)
    c.line(x, y, x + 100 * mm, y)
    for i in range(11):
        c.line(x + i * 10 * mm, y, x + i * 10 * mm, y + (4 * mm if i % 5 == 0 else 2 * mm))
    c.setFont("Helvetica", 8)
    c.drawString(x, y - 4 * mm, "check: this bar must measure exactly 100 mm")


def solid(c, col=CUT, w=1.0):
    c.setStrokeColor(col)
    c.setDash()
    c.setLineWidth(w)


def dashed(c, col=FOLD, w=0.7):
    c.setStrokeColor(col)
    c.setDash(3, 3)
    c.setLineWidth(w)


def label(c, x, y, text, size=7.5, col=NOTE):
    c.setFont("Helvetica", size)
    c.setFillColor(col)
    c.drawString(x, y, text)
    c.setFillColor(colors.black)


# -----------------------------------------------------------------------
def blade(c, x0, y0, n):
    """One blade blank.  x0,y0 = bottom-left of the body, in points."""
    full = BLADE_D + max(TRIMS)
    solid(c)
    c.rect(x0, y0, full * mm, BLADE_Z * mm)

    # datum: the line that goes level with the front of the LDR domes
    dx = x0 + BLADE_D * mm
    solid(c, DATUM, 1.4)
    c.line(dx, y0 - 3 * mm, dx, y0 + (BLADE_Z + 3) * mm)
    label(c, dx - 9 * mm, y0 + (BLADE_Z + 4.5) * mm, "DATUM", 7, DATUM)

    # trim ladder forward of the datum
    for t in TRIMS:
        tx = x0 + (BLADE_D + t) * mm
        dashed(c, colors.HexColor("#999999"), 0.6)
        c.line(tx, y0, tx, y0 + BLADE_Z * mm)
        c.saveState()
        c.translate(tx, y0 + 2 * mm)
        c.rotate(90)
        c.setFont("Helvetica", 6.5)
        c.setFillColor(NOTE)
        c.drawString(0, -2.0, "%.1f" % t)
        c.restoreState()

    # dome tabs: fold back along the datum, one each side
    for side in (0, 1):
        ty = y0 + (BLADE_Z - TAB - 3) * mm if side else y0 + 3 * mm
        solid(c)
        c.rect(dx, ty, TAB * mm, TAB * mm)
    dashed(c)
    c.line(dx, y0, dx, y0 + BLADE_Z * mm)

    label(c, x0, y0 - 6 * mm,
          "BLADE %d   %.0f mm tall, datum %.0f mm from the back edge, "
          "trim ladder 1.0 - 6.0 mm" % (n, BLADE_Z, BLADE_D))


def page_blade(c):
    hdr(c, A4, "SHEET 1  -  the centre blade  (the only part you make)",
        "Matte BLACK card, 0.5 - 1.0 mm, black on both faces. Cut four; you "
        "will trim two of them on the bench.\n"
        "Solid = cut.  Red = datum.  Grey dashes = the trim ladder.  "
        "Blue dashes = fold.")
    scalebar(c, 15 * mm, A4[1] - 34 * mm)

    for i in range(4):
        blade(c, 22 * mm, A4[1] - (75 + i * 46) * mm, i + 1)

    y = A4[1] - 262 * mm
    for line in [
        "HOW TO USE THE LADDER",
        "1  Slide the blade in between the two LDRs until the RED DATUM line is "
        "level with the front of the epoxy domes.",
        "2  Fold the two small tabs back against the domes. Their job is to close "
        "the gap between blade and cell:",
        "   that gap, not the blade height, is what blinds the blade near "
        "boresight, so press them right up to the epoxy.",
        "3  Trim the front edge down to the ladder line you want. Start at "
        "1.5 mm - see the trade table on sheet 2.",
        "4  The blade must stand the full height in Z and reach back past both "
        "cells, so no light crosses over behind it.",
    ]:
        label(c, 15 * mm, y, line, 8.2,
              colors.black if line.isupper() else NOTE)
        y -= 5.0 * mm
    c.showPage()


def page_plan(c):
    hdr(c, A4, "SHEET 2  -  geometry, alignment and the height trade",
        "Plan view from directly above.  The cells are fixed; only the blade "
        "is yours.")

    cx, cy = A4[0] / 2, A4[1] - 105 * mm
    S = 1.5 * mm
    Rp = 44

    c.setStrokeColor(NOTE)
    c.setDash(2, 2)
    c.setLineWidth(0.7)
    c.arc(cx - Rp * S, cy - Rp * S, cx + Rp * S, cy + Rp * S, 0, 180)
    c.setDash()
    for a, t in [(0, "0"), (20, "20"), (45, "45"), (90, "90"),
                 (135, "135"), (160, "160"), (180, "180")]:
        r = math.radians(a)
        ax, ay = cx + Rp * S * math.cos(r), cy + Rp * S * math.sin(r)
        c.setStrokeColor(DATUM if a in (20, 160) else NOTE)
        c.setLineWidth(1.4 if a in (20, 160) else 0.7)
        c.line(cx + (Rp - 4) * S * math.cos(r), cy + (Rp - 4) * S * math.sin(r), ax, ay)
        label(c, ax - 4 * mm, ay + 2 * mm, t,
              8, DATUM if a in (20, 160) else NOTE)
    c.setStrokeColor(NOTE)
    c.setLineWidth(0.7)
    c.line(cx - Rp * S, cy, cx + Rp * S, cy)

    # cells, splayed +-BETA about boresight (the 90 deg direction)
    for sgn, name, pin, col in ((+1, "A", "io17", "#0b6fb8"),
                                (-1, "B", "io16", "#0b6fb8")):
        ang = math.radians(90 - sgn * BETA)
        ox = cx + sgn * 5 * mm
        c.setFillColor(colors.HexColor(col))
        c.circle(ox, cy, 2.0 * mm, fill=1, stroke=0)
        c.setStrokeColor(colors.HexColor(col))
        c.setLineWidth(1.0)
        c.setDash(2, 2)
        c.line(ox, cy, ox + 26 * mm * math.cos(ang), cy + 26 * mm * math.sin(ang))
        c.setDash()
        label(c, ox + (14 if sgn > 0 else -40) * mm, cy + 26 * mm,
              "cell %s  %s" % (name, pin), 8, colors.HexColor(col))
    c.setFillColor(colors.black)

    # the blade, along boresight
    solid(c, DATUM, 3.0)
    c.line(cx, cy - 8 * mm, cx, cy + 14 * mm)
    solid(c, DATUM, 0.6)
    c.line(cx, cy + 14 * mm, cx - 22 * mm, cy + 22 * mm)
    label(c, cx - 62 * mm, cy + 23 * mm, "BLADE - stands along the 90 deg line", 8, DATUM)
    label(c, cx - 62 * mm, cy + 19.5 * mm, "h = how far it stands proud of the domes",
          8, DATUM)

    # dead sectors
    c.setFillColor(colors.HexColor("#f2e4d8"))
    for a0, a1 in ((0, 20), (160, 180)):
        p = c.beginPath()
        p.moveTo(cx, cy)
        p.arcTo(cx - Rp * S, cy - Rp * S, cx + Rp * S, cy + Rp * S, a0, a1 - a0)
        p.close()
        c.drawPath(p, stroke=0, fill=1)
    c.setFillColor(colors.black)
    label(c, cx + 40 * mm, cy + 6 * mm, "0 - 20 dead", 7, DATUM)
    label(c, cx - 58 * mm, cy + 6 * mm, "160 - 180 dead", 7, DATUM)

    y = cy - 22 * mm
    for line in [
        "THE HARD LIMIT",
        "A cosine cell is dark once the source is more than 90 deg off its own "
        "normal. Splayed 20 deg outward, cell A dies at",
        "160 deg on the protractor and cell B at 20 deg, so the RATIO can only "
        "work over 20 - 160. No blade changes that.",
        "The shaded wedges are covered instead by the amplitude of whichever "
        "cell is still lit - see the playbook.",
        "",
        "BLADE HEIGHT h  -  pure range against resolution   (w = 4.3 mm, tabs "
        "closing the gap)",
    ]:
        label(c, 15 * mm, y, line, 8.2, colors.black if line.isupper() else NOTE)
        y -= 5.0 * mm

    rows = [("h (mm)", "ratio zone", "res at 90", "res at 60", "res at 35", ""),
            ("0 (flush)", "20 - 160", "0.34", "0.24", "0.08", "no blade at all"),
            ("1.5", "20 - 160", "0.23", "0.15", "0.05", "recommended start"),
            ("3.0", "35 - 145", "0.18", "0.09", "dark", "gives up 30 deg of range"),
            ("6.0", "55 - 125", "0.12", "0.02", "dark", "null-seeking only")]
    y -= 3 * mm
    colx = [15, 45, 78, 105, 132, 158]
    for i, row in enumerate(rows):
        for cxx, cell in zip(colx, row):
            c.setFont("Helvetica-Bold" if i == 0 else "Helvetica", 8)
            c.setFillColor(colors.black if i in (0, 2) else NOTE)
            c.drawString(cxx * mm, y, cell)
        if i == 0:
            c.setStrokeColor(NOTE)
            c.setLineWidth(0.5)
            c.line(15 * mm, y - 1.5 * mm, 195 * mm, y - 1.5 * mm)
        y -= 5.0 * mm
    c.setFillColor(colors.black)

    y -= 3 * mm
    for line in [
        "Every millimetre of blade costs scored range at both ends and buys "
        "resolution only in the middle. With 0 - 180 scored,",
        "keep the range: h = 1.5 mm. Only go taller if the organisers confirm "
        "the LED stays near boresight.",
        "",
        "ALIGNMENT  -  where the degrees are actually lost",
        "Blade in the plane of the 90 deg line, square across the baseline. "
        "1 deg of twist is 1 deg of bias in every reading.",
        "Head centred on the protractor centre within 1 mm; 1 mm at R = 150 mm "
        "is 0.4 deg.",
        "Cell faces vertical, checked with a small square - that is what makes "
        "the reading ignore the LED's height.",
        "Matte black card on the deck under the head. Bounce adds to both cells, "
        "which divides the ratio down and",
        "flattens the whole curve.",
    ]:
        label(c, 15 * mm, y, line, 8.2, colors.black if line.isupper() else NOTE)
        y -= 5.0 * mm
    c.showPage()


def page_protractor(c):
    page = landscape(A3)
    c.setPageSize(page)
    hdr(c, page, "PRACTICE PROTRACTOR  -  R 150 mm, 1 deg ticks",
        "For the bench at home. Print A3 at 100%, or tile onto 2 x A4. "
        "The competition supplies its own.")
    cx, cy = page[0] / 2, 40 * mm
    R = 150 * mm
    c.setStrokeColor(colors.black)
    c.setLineWidth(0.8)
    c.arc(cx - R, cy - R, cx + R, cy + R, 0, 180)
    c.line(cx - R, cy, cx + R, cy)
    for a in range(0, 181):
        L = 9 * mm if a % 10 == 0 else (6 * mm if a % 5 == 0 else 3 * mm)
        c.setLineWidth(0.9 if a % 10 == 0 else 0.4)
        r = math.radians(a)
        c.line(cx + (R - L) * math.cos(r), cy + (R - L) * math.sin(r),
               cx + R * math.cos(r), cy + R * math.sin(r))
        if a % 10 == 0:
            c.setFont("Helvetica", 8)
            c.saveState()
            c.translate(cx + (R - 15 * mm) * math.cos(r),
                        cy + (R - 15 * mm) * math.sin(r))
            c.rotate(a - 90)
            c.drawCentredString(0, 0, str(a))
            c.restoreState()
    c.setLineWidth(0.8)
    c.circle(cx, cy, 1.5 * mm)
    c.line(cx, cy - 12 * mm, cx, cy + 12 * mm)
    c.line(cx - 12 * mm, cy, cx + 12 * mm, cy)
    c.setFont("Helvetica", 8)
    c.drawCentredString(cx, cy - 18 * mm,
                        "head centre here   -   blade along the 90 deg line")
    scalebar(c, 20 * mm, page[1] - 40 * mm)
    c.showPage()


def main():
    c = canvas.Canvas(OUT, pagesize=A4)
    c.setTitle("Centre blade - cutting templates")
    page_blade(c)
    page_plan(c)
    page_protractor(c)
    c.save()
    print("wrote", OUT)


if __name__ == "__main__":
    main()
