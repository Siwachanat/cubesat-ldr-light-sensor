#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CubeSat sensor competition - manual data collection + calibration GUI
=====================================================================

One file. Talks to the ESP32 over USB serial, captures one averaged point per
protractor angle, plots what matters, fits the curve, and prints a paste-ready
C block for calib.h.

Install (once, before the competition):
    pip install PyQt5 pyqtgraph pyserial numpy

Run:
    python comp_gui.py

Layout: a toolbar for what you set once (port, live readout, dark), a short
left column for what you touch during a sweep (angle, capture, the table), and
tabs on the right for the plots plus the constants and the fit. It fits a
1366x768 laptop with no scrolling; the left column scrolls anyway on anything
smaller, so nothing can end up off-screen.

Two ways to get points in, on the two tabs of panel 4:
    Serial capture   the board streams, the GUI averages a burst per angle
    Manual entry     you type cell A and cell B yourself, in mV or ADC counts,
                     one point at a time or as a pasted block of rows

Manual entry needs no board at all, so the whole fit-and-generate path works
from numbers on paper. Typed points carry no measured scatter, so set the
"noise mV" box to the per-sample ADC noise you expect and the resolution and
CAL_SIGMA figures stay meaningful.

Keyboard on the entry panel:
    Enter      add a point at the angle in the box (whichever tab is in front)
    Up/Down    step the angle by the step size
    Delete     delete the selected table row

The GUI does ALL the maths. The firmware only streams two voltages. That means
R_F, VREF, gamma and k can be wrong and the calibration still works - they are
absorbed by the lookup table. Only the dark reading and the geometry must be
right.
"""

import csv
import math
import os
import sys
import time
from collections import deque

import numpy as np

from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

try:
    import serial
    import serial.tools.list_ports
    HAVE_SERIAL = True
except Exception:                                    # pragma: no cover
    HAVE_SERIAL = False

APP_NAME = "CubeSat angle sensor - competition console"
VERSION = "1.3.0"

# ---------------------------------------------------------------------------
# core maths  (mirrored exactly in the ESP32 firmware)
# ---------------------------------------------------------------------------

GMIN = 1e-12                     # conductance floor, S


def conductance(v_mV, rf_ohm, vref_mV):
    """Node voltage -> LDR conductance.  3V3 - LDR - node - R_F - GND."""
    v = np.asarray(v_mV, dtype=float)
    v = np.clip(v, 1e-3, vref_mV - 1e-3)
    r_ldr = rf_ohm * (vref_mV / v - 1.0)             # ohm
    return 1.0 / np.maximum(r_ldr, 1e-6)


def irradiance(v_mV, rf_ohm, vref_mV, gd, gamma):
    """Voltage -> quantity proportional to irradiance.

    Dark leakage is removed as a CONDUCTANCE (that is the term that really adds
    in parallel), then the LDR power law is undone: G ~ E**gamma.
    """
    g = conductance(v_mV, rf_ohm, vref_mV) - gd
    g = np.maximum(g, GMIN)
    return np.power(g, 1.0 / gamma)


def sd_ln_irradiance(v_mV, sd_v, rf_ohm, vref_mV, gd, gamma):
    """Propagate ADC scatter into the scatter of ln(E) for one channel."""
    v = np.clip(np.asarray(v_mV, float), 1e-3, vref_mV - 1e-3)
    g = conductance(v, rf_ohm, vref_mV)
    dg_dv = vref_mV / (rf_ohm * (vref_mV - v) ** 2)
    return (1.0 / gamma) * dg_dv / np.maximum(g - gd, GMIN) * np.asarray(sd_v, float)


def log_ratio(eA, eB, lnk=0.0):
    """L = ln(E_A / (k E_B)).  Monotone in angle, unbounded, near-linear.

    L is the statistic the lookup table is built on.  D = tanh(L/2) is only
    ever used for display, because D saturates at +-1 and L does not.
    """
    eA = np.maximum(np.asarray(eA, dtype=float), GMIN)
    eB = np.maximum(np.asarray(eB, dtype=float), GMIN)
    return np.log(eA) - np.log(eB) - lnk


def cfloat(v, fmt="%.9g"):
    """Format a float as a valid C float literal.

    "%g" prints 0.0 as "0", and "0f" is not a number in C++ - it parses as a
    user-defined literal and the sketch will not compile. A dark reference of
    exactly zero (nobody pressed Measure DARK) hits this every time.
    """
    t = fmt % float(v)
    if not any(c in t for c in ".eEn"):
        t += ".0"
    return t + "f"


def L_to_D(L):
    return np.tanh(np.asarray(L, dtype=float) / 2.0)


# ---- shape preserving cubic (PCHIP, Fritsch-Carlson).  numpy only. ---------

def pchip_slopes(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = len(x)
    if n < 2:
        return np.zeros(n)
    h = np.diff(x)
    d = np.diff(y) / h
    m = np.zeros(n)
    if n == 2:
        m[:] = d[0]
        return m
    for k in range(1, n - 1):
        if d[k - 1] * d[k] <= 0:
            m[k] = 0.0
        else:
            w1 = 2 * h[k] + h[k - 1]
            w2 = h[k] + 2 * h[k - 1]
            m[k] = (w1 + w2) / (w1 / d[k - 1] + w2 / d[k])
    # shape preserving one sided ends
    m[0] = ((2 * h[0] + h[1]) * d[0] - h[0] * d[1]) / (h[0] + h[1])
    if m[0] * d[0] <= 0:
        m[0] = 0.0
    elif d[0] * d[1] <= 0 and abs(m[0]) > abs(3 * d[0]):
        m[0] = 3 * d[0]
    m[-1] = ((2 * h[-1] + h[-2]) * d[-1] - h[-1] * d[-2]) / (h[-1] + h[-2])
    if m[-1] * d[-1] <= 0:
        m[-1] = 0.0
    elif d[-1] * d[-2] <= 0 and abs(m[-1]) > abs(3 * d[-1]):
        m[-1] = 3 * d[-1]
    return m


def hermite(x, y, m, xq, derivative=False):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.asarray(m, float)
    scalar = np.isscalar(xq) or (np.asarray(xq).ndim == 0)
    xq = np.atleast_1d(np.asarray(xq, float))
    idx = np.clip(np.searchsorted(x, xq) - 1, 0, len(x) - 2)
    h = x[idx + 1] - x[idx]
    t = (xq - x[idx]) / h
    t2, t3 = t * t, t * t * t
    if not derivative:
        h00 = 2 * t3 - 3 * t2 + 1
        h10 = t3 - 2 * t2 + t
        h01 = -2 * t3 + 3 * t2
        h11 = t3 - t2
        out = (h00 * y[idx] + h10 * h * m[idx]
               + h01 * y[idx + 1] + h11 * h * m[idx + 1])
    else:
        g00 = 6 * t2 - 6 * t
        g10 = 3 * t2 - 4 * t + 1
        g01 = -6 * t2 + 6 * t
        g11 = 3 * t2 - 2 * t
        out = (g00 * y[idx] / h + g10 * m[idx]
               + g01 * y[idx + 1] / h + g11 * m[idx + 1])
    return float(out[0]) if scalar else out


class MonotoneCurve(object):
    """L(theta) fitted through the captured points, and its inverse."""

    def __init__(self, theta, L, n_dense=4001):
        order = np.argsort(theta)
        self.theta = np.asarray(theta, float)[order]
        self.L = np.asarray(L, float)[order]
        self.m = pchip_slopes(self.theta, self.L)
        self.td = np.linspace(self.theta[0], self.theta[-1], n_dense)
        self.Ld = hermite(self.theta, self.L, self.m, self.td)
        self.increasing = self.Ld[-1] > self.Ld[0]
        if self.increasing:
            self._Lm, self._tm = self.Ld, self.td
        else:
            self._Lm, self._tm = self.Ld[::-1], self.td[::-1]

    def L_of(self, theta):
        return hermite(self.theta, self.L, self.m, theta)

    def dLdtheta(self, theta):
        return hermite(self.theta, self.L, self.m, theta, derivative=True)

    def theta_of(self, L):
        out = np.interp(np.atleast_1d(L), self._Lm, self._tm)
        return float(out[0]) if np.asarray(L).ndim == 0 else out

    def L_span(self):
        return float(min(self.Ld)), float(max(self.Ld))


def floored_mask(logE, drop=0.5, min_range=3.0, min_run=3):
    """Which samples sit on a channel's flat stray-light floor.

    A cell that has gone geometrically dark stops responding: its log level
    flattens onto a shelf. Being merely dim is not the same thing, so a shelf
    only counts when the channel has real dynamic range (min_range in ln E)
    and at least min_run consecutive samples sit within `drop` of its minimum.
    Without this test a short ratio zone can lose out to a longer monotone run
    in the dead region, and the fit silently calibrates the wrong band.
    """
    logE = np.asarray(logE, float)
    out = np.zeros(len(logE), bool)
    if len(logE) < min_run or (logE.max() - logE.min()) < min_range:
        return out
    near = logE < logE.min() + drop
    run = 0
    for i, f in enumerate(near):
        run = run + 1 if f else 0
        if run >= min_run:
            out[i - run + 1:i + 1] = True
    return out


EDGE_K = 8.0        # a cell counts as lit at most this far above its own floor
NOISE_K = 25.0      # sdL this many times the quiet median means "not a signal"
AMP_SLOPE_MIN = 0.003   # ln E per degree; below this a level table is padding


def cell_dark_threshold(e, k=EDGE_K):
    """Split ONE channel into lit and dark, and return its darkness threshold.

    Each cell needs its own number. Two LDRs on the same deck routinely sit an
    order of magnitude apart in stray light - a shared threshold then lands
    above one cell's floor and below the other's, and the cell whose floor is
    higher is never recognised as dark at all. That single mistake costs a
    whole outer sector: the ratio saturates, folds back inside the table, and
    the level branch is never reached.

    The split is the midpoint of the channel's own ln range. Between shadowed
    and lit there are typically three decades, so the midpoint lands in open
    air on the cliff, nowhere near either side, and needs no tuning. The floor
    is then the median of the dark side, and the threshold goes at the
    GEOMETRIC MEAN of that floor and the dimmest lit reading - the placement
    that leaves the largest factor of margin on both sides at once, which is
    what decides how far the LED may drift before the branch flips. It is
    clipped so it can never sit within 2x of the floor, nor more than EDGE_K
    above it if the dimmest lit reading turns out to be optimistic.

    Returns (threshold, floor, lit_mask).
    """
    le = np.log(np.maximum(np.asarray(e, float), GMIN))
    if len(le) < 4 or (le.max() - le.min()) < 1.0:
        return GMIN, GMIN, np.ones(len(le), bool)     # never goes dark here
    mid = 0.5 * (le.min() + le.max())
    dark = le <= mid
    if dark.sum() < 2 or (~dark).sum() < 2:
        return GMIN, GMIN, np.ones(len(le), bool)
    # The dark side is part floor and part shadow ramp, and a median over it
    # sits on the ramp when the ramp is well sampled. The 20th percentile is
    # on the floor either way, and unlike the single minimum it does not move
    # with one noisy sample.
    lo = float(np.percentile(le[dark], 20))
    lit_lo = float(np.min(le[~dark]))          # the dimmest genuinely lit one
    t = lo + np.log(3.3)                       # clear of the floor's scatter
    t = min(t, lit_lo - np.log(1.5), lo + np.log(k))
    t = max(t, lo + np.log(1.5))
    return float(np.exp(t)), float(np.exp(lo)), np.asarray(e, float) > np.exp(t)


def longest_monotone_span(theta, L, valid=None):
    """Largest contiguous angle span over which L is strictly monotone."""
    theta = np.asarray(theta, float)
    L = np.asarray(L, float)
    if len(theta) < 2:
        return 0.0, (0.0, 0.0)
    d = np.sign(np.diff(L))
    if valid is not None:
        v = np.asarray(valid, bool)
        d = np.where(v[:-1] & v[1:], d, 0.0)
    best_len, best = 0.0, (theta[0], theta[0])
    i = 0
    while i < len(d):
        if d[i] == 0:
            i += 1
            continue
        j = i
        while j + 1 < len(d) and d[j + 1] == d[i]:
            j += 1
        span = theta[j + 1] - theta[i]
        if span > best_len:
            best_len, best = span, (theta[i], theta[j + 1])
        i = j + 1
    return best_len, best


def build_lut(curve, n_rows=48, lo_frac=0.0, hi_frac=1.0):
    """Sample theta(L) on a grid that is UNIFORM IN L.

    Uniform in L, not uniform in angle, because that is what equalises the
    interpolation error: the firmware then indexes the table directly with
    idx = (L - L0)/dL, no search at all.
    """
    Lmin, Lmax = curve.L_span()
    span = Lmax - Lmin
    L0 = Lmin + lo_frac * span
    L1 = Lmin + hi_frac * span
    Lg = np.linspace(L0, L1, n_rows)
    th = curve.theta_of(Lg)
    return L0, (L1 - L0) / (n_rows - 1), th, Lg


def lut_lookup(L0, dL, table, L):
    """Exactly what the firmware does - used here to check the round trip."""
    n = len(table)
    Lin = np.asarray(L, float)
    x = (np.atleast_1d(Lin) - L0) / dL
    xi = np.clip(np.floor(x), 0, n - 2).astype(int)
    f = np.clip(x - xi, 0.0, 1.0)
    f = np.where(x < 0, 0.0, f)
    f = np.where(x > n - 1, 1.0, f)
    out = np.asarray(table)[xi] + f * (np.asarray(table)[xi + 1] - np.asarray(table)[xi])
    return float(out[0]) if Lin.ndim == 0 else out


# ---------------------------------------------------------------------------
# serial reader thread
# ---------------------------------------------------------------------------

class SerialReader(QtCore.QThread):
    line = QtCore.pyqtSignal(str)
    failed = QtCore.pyqtSignal(str)

    def __init__(self, port, baud=115200, parent=None):
        super(SerialReader, self).__init__(parent)
        self.port, self.baud = port, baud
        self._run = True
        self.ser = None

    def run(self):
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.2)
            time.sleep(0.3)
            self.ser.reset_input_buffer()
        except Exception as exc:
            self.failed.emit(str(exc))
            return
        buf = b""
        while self._run:
            try:
                chunk = self.ser.read(256)
            except Exception as exc:
                self.failed.emit(str(exc))
                return
            if chunk:
                buf += chunk
                while b"\n" in buf:
                    raw, buf = buf.split(b"\n", 1)
                    self.line.emit(raw.decode("ascii", "replace").strip())
            else:
                self.msleep(5)
        try:
            self.ser.close()
        except Exception:
            pass

    def send(self, text):
        if self.ser is not None and self.ser.is_open:
            try:
                self.ser.write((text.strip() + "\n").encode())
            except Exception:
                pass

    def stop(self):
        self._run = False
        self.wait(1500)


# ---------------------------------------------------------------------------
# main window
# ---------------------------------------------------------------------------

pg.setConfigOptions(antialias=True, background="w", foreground="k")

PEN_A = pg.mkPen("#0b6fb8", width=2)
PEN_B = pg.mkPen("#c1440e", width=2)
PEN_FIT = pg.mkPen("#111111", width=2)
PEN_GRAY = pg.mkPen("#888888", width=1, style=QtCore.Qt.DashLine)
OVERLAY_PENS = ["#1b7f4b", "#7b4bd6", "#b8860b", "#008b8b", "#a0522d"]


class Main(QtWidgets.QMainWindow):

    def __init__(self):
        super(Main, self).__init__()
        self.setWindowTitle("%s  v%s" % (APP_NAME, VERSION))
        # Fits a 1366x768 laptop with room for the OS chrome. Everything that
        # is not needed during a sweep lives in the toolbar or a tab, and the
        # left column scrolls, so nothing can end up off-screen.
        self.resize(1280, 700)
        self.setMinimumSize(940, 540)

        self.reader = None
        self.rows = []                 # captured points
        self.overlays = []             # [(label, theta, L)]
        self.live = deque(maxlen=600)  # (t, vA, vB, L)
        self.capture_buf = None
        self.capture_target = 0
        self.capture_angle = 0.0
        self.capture_note = ""
        self.capture_is_dark = False
        self.t0 = time.time()
        self.last_curve = None
        self.last_lut = None
        self.gd = [0.0, 0.0]

        self._build_ui()
        self._refresh_ports()

        self.ui_timer = QtCore.QTimer(self)
        self.ui_timer.timeout.connect(self._tick)
        self.ui_timer.start(100)

    # -- ui ----------------------------------------------------------------

    # -- ui ----------------------------------------------------------------
    #
    # Layout rule: the left column holds only what you touch DURING a sweep -
    # the angle box, the capture button and the growing table. Everything you
    # set once (port, constants, dark, the fit) lives in the toolbar or in a
    # tab, so the column stays short enough for a 768-pixel laptop screen.
    # It is inside a scroll area as well, so nothing can ever be unreachable.

    def _sep(self):
        f = QtWidgets.QFrame()
        f.setFrameShape(QtWidgets.QFrame.VLine)
        f.setStyleSheet("color:#c8c8c8;")
        return f

    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(7, 6, 7, 4)
        root.setSpacing(6)

        root.addWidget(self._build_toolbar())

        split = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        split.setChildrenCollapsible(False)
        split.addWidget(self._build_left())
        split.addWidget(self._build_tabs())
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([482, 798])
        root.addWidget(split, 1)

        self.statusBar().showMessage("ready")

    # ---- toolbar: port, live readout, dark.  Set once, watched always. ----
    def _build_toolbar(self):
        bar = QtWidgets.QFrame()
        bar.setFrameShape(QtWidgets.QFrame.StyledPanel)
        h = QtWidgets.QHBoxLayout(bar)
        h.setContentsMargins(8, 5, 8, 5)
        h.setSpacing(8)

        h.addWidget(QtWidgets.QLabel("<b>1</b> Port"))
        self.cmb_port = QtWidgets.QComboBox()
        self.cmb_port.setMinimumWidth(190)
        h.addWidget(self.cmb_port)
        b = QtWidgets.QPushButton("Scan")
        b.setMaximumWidth(56)
        b.clicked.connect(self._refresh_ports)
        h.addWidget(b)
        self.btn_conn = QtWidgets.QPushButton("Connect")
        self.btn_conn.setMaximumWidth(96)
        self.btn_conn.clicked.connect(self._toggle_connect)
        h.addWidget(self.btn_conn)

        h.addWidget(self._sep())

        h.addWidget(QtWidgets.QLabel("<b>2</b> Live"))
        # E_A and E_B are derived and rarely watched, so they live on the
        # Setup and fit tab; the four here are the ones you read mid-sweep.
        self.lbl = {k: QtWidgets.QLabel("-") for k in ("vA", "vB", "eA", "eB", "L", "D")}
        for key, text in (("vA", "V_A"), ("vB", "V_B"), ("L", "L"), ("D", "D")):
            cap = QtWidgets.QLabel(text)
            cap.setStyleSheet("color:#777;font-size:11px;")
            h.addWidget(cap)
            lab = self.lbl[key]
            lab.setStyleSheet("font-family:monospace;font-weight:bold;")
            lab.setMinimumWidth(54)
            lab.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
            h.addWidget(lab)

        h.addWidget(self._sep())

        h.addWidget(QtWidgets.QLabel("<b>3</b>"))
        self.btn_dark = QtWidgets.QPushButton("DARK  (LED off)")
        self.btn_dark.clicked.connect(self.capture_dark)
        h.addWidget(self.btn_dark)
        self.edit_dark = QtWidgets.QLineEdit()
        self.edit_dark.setPlaceholderText("or type dark A, B")
        self.edit_dark.setMaximumWidth(126)
        self.edit_dark.setToolTip(
            "Two numbers in the units selected on the Manual entry tab, "
            "read with the LED off.")
        self.edit_dark.returnPressed.connect(self.set_dark_manual)
        h.addWidget(self.edit_dark)
        b = QtWidgets.QPushButton("Set")
        b.setMaximumWidth(46)
        b.clicked.connect(self.set_dark_manual)
        h.addWidget(b)

        h.addStretch(1)

        col = QtWidgets.QVBoxLayout()
        col.setSpacing(0)
        self.lbl_status = QtWidgets.QLabel("not connected")
        self.lbl_status.setStyleSheet("color:#555;font-size:11px;")
        self.lbl_dark = QtWidgets.QLabel("dark not measured")
        self.lbl_dark.setStyleSheet("font-family:monospace;font-size:11px;color:#b00;")
        col.addWidget(self.lbl_status)
        col.addWidget(self.lbl_dark)
        h.addLayout(col)
        return bar

    # ---- left column: only what you touch during a sweep ------------------
    def _build_left(self):
        panel = QtWidgets.QWidget()
        left = QtWidgets.QVBoxLayout(panel)
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(6)

        gb = QtWidgets.QGroupBox("4  Add a point   (LED ON)")
        gv = QtWidgets.QVBoxLayout(gb)
        gv.setContentsMargins(8, 6, 8, 8)
        gv.setSpacing(5)
        g = QtWidgets.QGridLayout()
        g.setSpacing(5)
        gv.addLayout(g)
        g.addWidget(QtWidgets.QLabel("Angle"), 0, 0)
        self.spin_angle = QtWidgets.QDoubleSpinBox()
        self.spin_angle.setRange(-360, 360)
        self.spin_angle.setDecimals(1)
        # The competition protractor reads -85..+85 about its own centre, so
        # start at 0, not 90. Nothing downstream cares what the numbers are -
        # the fit, the tables and the firmware all carry whatever you type.
        self.spin_angle.setValue(0.0)
        self.spin_angle.setSingleStep(5.0)
        self.spin_angle.setStyleSheet("font-size:19px;font-weight:bold;")
        g.addWidget(self.spin_angle, 0, 1)
        g.addWidget(QtWidgets.QLabel("Step"), 0, 2)
        self.spin_step = QtWidgets.QDoubleSpinBox()
        self.spin_step.setRange(0.5, 45)
        self.spin_step.setValue(5.0)
        self.spin_step.valueChanged.connect(
            lambda v: self.spin_angle.setSingleStep(v))
        g.addWidget(self.spin_step, 0, 3)
        g.addWidget(QtWidgets.QLabel("Label"), 1, 0)
        self.edit_note = QtWidgets.QLineEdit("run1")
        g.addWidget(self.edit_note, 1, 1)
        self.chk_auto = QtWidgets.QCheckBox("advance angle")
        self.chk_auto.setChecked(True)
        g.addWidget(self.chk_auto, 1, 2, 1, 2)

        self.tabs_entry = QtWidgets.QTabWidget()
        gv.addWidget(self.tabs_entry)

        w = QtWidgets.QWidget()
        t = QtWidgets.QGridLayout(w)
        t.setContentsMargins(7, 7, 7, 7)
        t.setSpacing(5)
        t.addWidget(QtWidgets.QLabel("Samples"), 0, 0)
        self.spin_n = QtWidgets.QSpinBox()
        self.spin_n.setRange(4, 400)
        self.spin_n.setValue(40)
        t.addWidget(self.spin_n, 0, 1)
        self.btn_cap = QtWidgets.QPushButton("CAPTURE   (Enter)")
        self.btn_cap.setStyleSheet(
            "font-size:15px;font-weight:bold;padding:7px;"
            "background:#1b7f4b;color:white;")
        self.btn_cap.clicked.connect(self.capture_point)
        t.addWidget(self.btn_cap, 0, 2, 1, 2)
        self.prog = QtWidgets.QProgressBar()
        self.prog.setMaximumHeight(9)
        self.prog.setTextVisible(False)
        t.addWidget(self.prog, 1, 0, 1, 4)
        self.tabs_entry.addTab(w, "Serial capture")

        w = QtWidgets.QWidget()
        t = QtWidgets.QGridLayout(w)
        t.setContentsMargins(7, 7, 7, 7)
        t.setSpacing(5)
        t.addWidget(QtWidgets.QLabel("Units"), 0, 0)
        self.cmb_unit = QtWidgets.QComboBox()
        self.cmb_unit.addItems(["node voltage, mV", "ADC counts"])
        self.cmb_unit.currentIndexChanged.connect(self._unit_changed)
        t.addWidget(self.cmb_unit, 0, 1)
        self.lbl_fs = QtWidgets.QLabel("full scale")
        t.addWidget(self.lbl_fs, 0, 2)
        self.spin_fs = QtWidgets.QSpinBox()
        self.spin_fs.setRange(255, 65535)
        self.spin_fs.setValue(4095)
        t.addWidget(self.spin_fs, 0, 3)
        t.addWidget(QtWidgets.QLabel("A  io17"), 1, 0)
        self.edit_a = QtWidgets.QLineEdit()
        self.edit_a.setStyleSheet("font-family:monospace;font-size:14px;")
        t.addWidget(self.edit_a, 1, 1)
        t.addWidget(QtWidgets.QLabel("B  io16"), 1, 2)
        self.edit_b = QtWidgets.QLineEdit()
        self.edit_b.setStyleSheet("font-family:monospace;font-size:14px;")
        t.addWidget(self.edit_b, 1, 3)
        for e in (self.edit_a, self.edit_b):
            e.returnPressed.connect(self.add_manual)
        b = QtWidgets.QPushButton("ADD POINT   (Enter)")
        b.setStyleSheet("font-size:14px;font-weight:bold;padding:6px;"
                        "background:#1b7f4b;color:white;")
        b.clicked.connect(self.add_manual)
        t.addWidget(b, 2, 0, 1, 3)
        self.spin_noise = QtWidgets.QDoubleSpinBox()
        self.spin_noise.setRange(0.1, 200.0)
        self.spin_noise.setValue(2.0)
        self.spin_noise.setDecimals(1)
        self.spin_noise.setPrefix("sd ")
        self.spin_noise.setToolTip(
            "Typed points carry no measured scatter, so the fit assumes this much\n"
            "ADC noise per channel when it works out resolution and CAL_SIGMA.")
        t.addWidget(self.spin_noise, 2, 3)
        # The paste block is for typing up a run from paper, not for a live
        # sweep, so it starts folded away - that is ~90 px of column height
        # back on a short screen.
        self.btn_paste = QtWidgets.QPushButton("Paste a block of rows...")
        self.btn_paste.setCheckable(True)
        self.btn_paste.toggled.connect(self._toggle_paste)
        t.addWidget(self.btn_paste, 3, 0, 1, 4)
        self.txt_paste = QtWidgets.QPlainTextEdit()
        self.txt_paste.setPlaceholderText(
            "angle  A  B   one row per line   (comma, tab or space)")
        self.txt_paste.setStyleSheet("font-family:monospace;font-size:11px;")
        self.txt_paste.setMaximumHeight(56)
        self.txt_paste.hide()
        t.addWidget(self.txt_paste, 4, 0, 1, 4)
        self.btn_paste_add = QtWidgets.QPushButton("Add all pasted rows")
        self.btn_paste_add.clicked.connect(self.add_pasted)
        self.btn_paste_add.hide()
        t.addWidget(self.btn_paste_add, 5, 0, 1, 4)
        self.tabs_entry.addTab(w, "Manual entry")
        self._unit_changed()

        left.addWidget(gb)

        for key in ("Return", "Enter"):
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(key), self)
            sc.activated.connect(self.add_point)

        gb = QtWidgets.QGroupBox("5  Points")
        v = QtWidgets.QVBoxLayout(gb)
        v.setContentsMargins(8, 6, 8, 8)
        v.setSpacing(5)
        self.table = QtWidgets.QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["angle", "V_A", "V_B", "L", "sd L", "label"])
        self.table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Stretch)
        self.table.horizontalHeader().setMinimumSectionSize(46)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setMinimumHeight(110)
        self.table.verticalHeader().setDefaultSectionSize(20)
        self.table.verticalHeader().setVisible(False)
        v.addWidget(self.table, 1)
        h = QtWidgets.QHBoxLayout()
        h.setSpacing(4)
        for text, tip, slot in (
                ("Delete", "delete the selected row", self.delete_row),
                ("Clear", "delete every point", self.clear_rows),
                ("Load", "load a sweep from CSV", self.load_csv),
                ("Save", "save this sweep to CSV", self.save_csv),
                ("Overlay", "add another CSV to the Compare tab", self.add_overlay),
                ("Re-zero", "shift every angle by a constant, to move a sweep "
                            "onto a differently-zeroed protractor", self.rezero)):
            b = QtWidgets.QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            h.addWidget(b)
        v.addLayout(h)
        left.addWidget(gb, 1)
        QtWidgets.QShortcut(QtGui.QKeySequence("Delete"),
                            self.table).activated.connect(self.delete_row)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(panel)
        scroll.setMinimumWidth(462)
        return scroll

    # ---- right: the plots, plus the once-per-session settings and the fit --
    def _build_tabs(self):
        self.tabs = QtWidgets.QTabWidget()

        self.p_resp = self._plot("angle on protractor  (deg)", "E  (arb, normalised)")
        self.tabs.addTab(self._wrap(self.p_resp,
                                    "What each cell sees. Each peaks at its own normal; the "
                                    "gap between the peaks is twice the splay."), "Response")

        self.p_curve = self._plot("angle on protractor  (deg)", "L")
        self.tabs.addTab(self._wrap(self.p_curve,
                                    "The calibration curve. It must be strictly monotone over "
                                    "the range you intend to report."), "Curve")

        self.p_res = self._plot("angle on protractor  (deg)", "resolution  (deg)")
        self.tabs.addTab(self._wrap(self.p_res,
                                    "sigma_theta = sigma_L / |dL/dtheta|. The number the "
                                    "competition actually scores."), "Resolution")

        self.p_resid = self._plot("angle on protractor  (deg)", "error  (deg)")
        self.tabs.addTab(self._wrap(self.p_resid,
                                    "Point minus fit, and the error the firmware's own table "
                                    "lookup would make."), "Residuals")

        self.p_live = self._plot("time  (s)", "L")
        self.tabs.addTab(self._wrap(self.p_live,
                                    "Live L. Flat = settled and quiet. Judge settle time and "
                                    "noise here before you capture."), "Live")

        self.p_cmp = self._plot("angle on protractor  (deg)", "L")
        self.tabs.addTab(self._wrap(self.p_cmp,
                                    "Overlay of saved sweeps. Steeper and monotone over a "
                                    "wider span wins."), "Compare")

        self.tabs.addTab(self._build_fit_tab(), "Setup and fit")
        return self.tabs

    def _build_fit_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(10, 10, 10, 8)
        v.setSpacing(8)

        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Live irradiance"))
        for key, text in (("eA", "E_A"), ("eB", "E_B")):
            cap = QtWidgets.QLabel(text)
            cap.setStyleSheet("color:#777;font-size:11px;")
            row.addWidget(cap)
            lab = self.lbl[key]
            lab.setStyleSheet("font-family:monospace;font-weight:bold;")
            lab.setMinimumWidth(84)
            row.addWidget(lab)
        hint = QtWidgets.QLabel(
            "<span style='color:#777'>on its floor = a dark cell</span>")
        hint.setToolTip("This is what the branch test looks at: below "
                        "CAL_E_EDGE a cell counts as dark and the level "
                        "estimator takes over.")
        row.addWidget(hint)
        row.addStretch(1)
        v.addLayout(row)

        gb = QtWidgets.QGroupBox("Constants   (set once - the table absorbs all of them)")
        g = QtWidgets.QGridLayout(gb)
        g.setSpacing(6)
        self.sp = {}
        for i, (key, text, val, dec) in enumerate((
                ("vref", "VREF mV", 3300.0, 0), ("rfa", "R_F A", 8200.0, 0),
                ("rfb", "R_F B", 8200.0, 0), ("ga", "gam A", 0.70, 2),
                ("gb", "gam B", 0.70, 2))):
            g.addWidget(QtWidgets.QLabel(text), 0, i * 2)
            sp = QtWidgets.QDoubleSpinBox()
            sp.setRange(0.05, 100000)
            sp.setDecimals(dec)
            sp.setValue(val)
            sp.setMaximumWidth(76)
            g.addWidget(sp, 0, i * 2 + 1)
            self.sp[key] = sp
        g.setColumnStretch(10, 1)
        v.addWidget(gb)

        gb = QtWidgets.QGroupBox("6  Fit and export")
        g = QtWidgets.QGridLayout(gb)
        g.setSpacing(6)
        g.addWidget(QtWidgets.QLabel("Boresight angle"), 0, 0)
        self.spin_bore = QtWidgets.QDoubleSpinBox()
        self.spin_bore.setRange(-360, 360)
        self.spin_bore.setValue(0.0)
        self.spin_bore.setMaximumWidth(88)
        g.addWidget(self.spin_bore, 0, 1)
        g.addWidget(QtWidgets.QLabel("LUT rows"), 0, 2)
        self.spin_rows = QtWidgets.QSpinBox()
        self.spin_rows.setRange(8, 256)
        self.spin_rows.setValue(128)   # 64 leaves table interpolation as the biggest error
        self.spin_rows.setMaximumWidth(88)
        g.addWidget(self.spin_rows, 0, 3)
        b = QtWidgets.QPushButton("FIT + GENERATE")
        b.setToolTip("Fit the sweep and build the calib.h block")
        b.setStyleSheet("font-size:14px;font-weight:bold;padding:7px;"
                        "background:#0b6fb8;color:white;")
        b.clicked.connect(self.do_fit)
        g.addWidget(b, 0, 4)
        bb = QtWidgets.QPushButton("Save calib.h")
        bb.clicked.connect(self.save_h)
        g.addWidget(bb, 0, 5)
        bb = QtWidgets.QPushButton("Copy")
        bb.clicked.connect(self.copy_out)
        g.addWidget(bb, 0, 6)
        g.setColumnStretch(7, 1)
        v.addWidget(gb)

        self.txt_out = QtWidgets.QPlainTextEdit()
        self.txt_out.setStyleSheet("font-family:monospace;font-size:11.5px;")
        self.txt_out.setPlaceholderText(
            "Press FIT + GENERATE after the sweep.\n\n"
            "The summary lands here; read every line before you flash. "
            "Save calib.h overwrites the header directly - no copying, no "
            "pasting, nothing to get wrong.")
        v.addWidget(self.txt_out, 1)
        return w

    def _plot(self, xlabel, ylabel):
        p = pg.PlotWidget()
        p.showGrid(x=True, y=True, alpha=0.25)
        p.setLabel("bottom", xlabel)
        p.setLabel("left", ylabel)
        p.addLegend(offset=(-10, 10))
        return p

    def _wrap(self, plot, caption):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(plot, 1)
        lab = QtWidgets.QLabel(caption)
        lab.setWordWrap(True)
        lab.setStyleSheet("color:#555;padding:4px;")
        v.addWidget(lab)
        return w

    # -- serial ------------------------------------------------------------

    def _refresh_ports(self):
        self.cmb_port.clear()
        if not HAVE_SERIAL:
            self.cmb_port.addItem("pyserial not installed")
            return
        ports = list(serial.tools.list_ports.comports())
        for p in ports:
            self.cmb_port.addItem("%s  -  %s" % (p.device, p.description), p.device)
        if not ports:
            self.cmb_port.addItem("no port found")

    def _toggle_connect(self):
        if self.reader is not None:
            self.reader.stop()
            self.reader = None
            self.btn_conn.setText("Connect")
            self.lbl_status.setText("disconnected")
            return
        dev = self.cmb_port.currentData()
        if not dev:
            QtWidgets.QMessageBox.warning(self, "No port", "Pick a serial port first.")
            return
        self.reader = SerialReader(dev)
        self.reader.line.connect(self.on_line)
        self.reader.failed.connect(self.on_serial_fail)
        self.reader.start()
        self.btn_conn.setText("Disconnect")
        self.lbl_status.setText("connected to %s" % dev)
        QtCore.QTimer.singleShot(600, lambda: self.reader and self.reader.send("MODE RAW"))

    def on_serial_fail(self, msg):
        self.lbl_status.setText("serial error: %s" % msg)
        self.btn_conn.setText("Connect")
        self.reader = None

    def on_line(self, line):
        if not line.startswith("T,"):
            if line:
                self.statusBar().showMessage(line, 4000)
            return
        parts = line.split(",")
        if len(parts) < 4:
            return
        try:
            vA = float(parts[2])
            vB = float(parts[3])
        except ValueError:
            return
        eA, eB = self._irr(vA, vB)
        eA, eB = float(eA), float(eB)
        L = float(log_ratio(eA, eB))
        self.live.append((time.time() - self.t0, vA, vB, L))
        self.lbl["vA"].setText("%8.1f" % vA)
        self.lbl["vB"].setText("%8.1f" % vB)
        self.lbl["eA"].setText("%.4g" % eA)
        self.lbl["eB"].setText("%.4g" % eB)
        self.lbl["L"].setText("%+8.4f" % L)
        self.lbl["D"].setText("%+8.4f" % float(L_to_D(L)))
        if self.capture_buf is not None:
            self.capture_buf.append((vA, vB))
            self.prog.setValue(int(100 * len(self.capture_buf) / self.capture_target))
            if len(self.capture_buf) >= self.capture_target:
                self._finish_capture()

    def _irr(self, vA, vB):
        """Voltages -> irradiance.  Works on scalars and on arrays."""
        eA = irradiance(vA, self.sp["rfa"].value(), self.sp["vref"].value(),
                        self.gd[0], self.sp["ga"].value())
        eB = irradiance(vB, self.sp["rfb"].value(), self.sp["vref"].value(),
                        self.gd[1], self.sp["gb"].value())
        return eA, eB

    # -- capture -----------------------------------------------------------

    def _start_capture(self, is_dark):
        if self.reader is None:
            QtWidgets.QMessageBox.warning(self, "Not connected", "Connect first.")
            return False
        self.capture_buf = []
        self.capture_target = max(4, self.spin_n.value())
        self.capture_is_dark = is_dark
        self.capture_angle = self.spin_angle.value()
        self.capture_note = self.edit_note.text().strip()
        self.prog.setValue(0)
        self.btn_cap.setEnabled(False)
        self.btn_dark.setEnabled(False)
        return True

    # -- manual entry ------------------------------------------------------

    def _toggle_paste(self, on):
        self.txt_paste.setVisible(on)
        self.btn_paste_add.setVisible(on)
        self.btn_paste.setText("Paste a block of rows..." if not on
                               else "Hide the paste box")
        if on:
            self.txt_paste.setFocus()

    def _unit_changed(self):
        counts = self.cmb_unit.currentIndex() == 1
        self.lbl_fs.setVisible(counts)
        self.spin_fs.setVisible(counts)
        hint = ("e.g. 2300", "e.g. 2411") if not counts else ("e.g. 2855", "e.g. 2992")
        self.edit_a.setPlaceholderText(hint[0])
        self.edit_b.setPlaceholderText(hint[1])

    MIN_MV = 5.0          # below this a channel is pinned, not measuring

    def _mv_ok(self, v):
        vref = self.sp["vref"].value()
        return self.MIN_MV < v < vref - self.MIN_MV

    def _to_mV(self, x):
        """Whatever the user typed -> node voltage in mV."""
        if self.cmb_unit.currentIndex() == 1:            # ADC counts
            return float(x) / float(self.spin_fs.value()) * self.sp["vref"].value()
        return float(x)

    def add_point(self):
        """Enter key: whichever entry tab is in front."""
        if self.tabs_entry.currentIndex() == 0:
            self.capture_point()
        else:
            self.add_manual()

    def _make_row(self, angle, vA, vB, note):
        """One row from two node voltages, with synthesised scatter."""
        sdv = self.spin_noise.value()
        eA, eB = self._irr(vA, vB)
        sdlA = sd_ln_irradiance(vA, sdv, self.sp["rfa"].value(),
                                self.sp["vref"].value(), self.gd[0],
                                self.sp["ga"].value())
        sdlB = sd_ln_irradiance(vB, sdv, self.sp["rfb"].value(),
                                self.sp["vref"].value(), self.gd[1],
                                self.sp["gb"].value())
        return dict(angle=float(angle), vA=float(vA), vB=float(vB),
                    sdvA=sdv, sdvB=sdv,
                    L=float(log_ratio(eA, eB)),
                    sdL=float(np.hypot(sdlA, sdlB)), n=1, note=note)

    def _insert(self, row):
        for i, r in enumerate(self.rows):
            if abs(r["angle"] - row["angle"]) < 1e-6 and r["note"] == row["note"]:
                self.rows[i] = row
                return
        self.rows.append(row)

    def add_manual(self):
        try:
            vA = self._to_mV(self.edit_a.text().strip())
            vB = self._to_mV(self.edit_b.text().strip())
        except ValueError:
            self.statusBar().showMessage(
                "type a number in both cell boxes first", 4000)
            return
        if not (self._mv_ok(vA) and self._mv_ok(vB)):
            QtWidgets.QMessageBox.warning(
                self, "Out of range",
                "Both readings must sit between %.0f mV and VREF - %.0f mV "
                "(VREF = %.0f mV).\n\nA channel pinned at either rail is not "
                "measuring anything, and a point like that poisons the table.\n"
                "If you are typing ADC counts, switch Units and set the full scale."
                % (self.MIN_MV, self.MIN_MV, self.sp["vref"].value()))
            return
        row = self._make_row(self.spin_angle.value(), vA, vB,
                             self.edit_note.text().strip())
        self._insert(row)
        self.rows.sort(key=lambda r: (r["note"], r["angle"]))
        self._refresh_table()
        self._replot_points()
        self.edit_a.clear()
        self.edit_b.clear()
        self.edit_a.setFocus()
        if self.chk_auto.isChecked():
            self.spin_angle.setValue(self.spin_angle.value() + self.spin_step.value())
        self.statusBar().showMessage(
            "added %.1f deg   L=%+.4f" % (row["angle"], row["L"]), 4000)

    def add_pasted(self):
        text = self.txt_paste.toPlainText()
        note = self.edit_note.text().strip()
        added, bad = 0, []
        for n, line in enumerate(text.splitlines(), 1):
            line = line.strip().replace(",", " ").replace("\t", " ")
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 3:
                bad.append(n)
                continue
            try:
                ang = float(parts[0])
                vA = self._to_mV(parts[1])
                vB = self._to_mV(parts[2])
            except ValueError:
                bad.append(n)
                continue
            if not (self._mv_ok(vA) and self._mv_ok(vB)):
                bad.append(n)
                continue
            self._insert(self._make_row(ang, vA, vB, note))
            added += 1
        self.rows.sort(key=lambda r: (r["note"], r["angle"]))
        self._refresh_table()
        self._replot_points()
        msg = "added %d rows" % added
        if bad:
            msg += "   -   skipped lines: %s" % ", ".join(str(b) for b in bad[:12])
        self.statusBar().showMessage(msg, 9000)
        if added and not bad:
            self.txt_paste.clear()

    def set_dark_manual(self):
        parts = self.edit_dark.text().replace(",", " ").split()
        if len(parts) < 2:
            self.statusBar().showMessage("type two numbers: dark A, dark B", 4000)
            return
        try:
            vA = self._to_mV(parts[0])
            vB = self._to_mV(parts[1])
        except ValueError:
            self.statusBar().showMessage("those are not numbers", 4000)
            return
        gA = float(conductance(vA, self.sp["rfa"].value(), self.sp["vref"].value()))
        gB = float(conductance(vB, self.sp["rfb"].value(), self.sp["vref"].value()))
        self.gd = [gA, gB]
        leak = vA > 200 or vB > 200
        self.lbl_dark.setText("G_dark  A: %.6g S   B: %.6g S      "
                              "(typed: %.0f mV, %.0f mV)%s"
                              % (gA, gB, vA, vB,
                                 "   <-- ABOVE 200 mV: light is leaking in" if leak else ""))
        self.lbl_dark.setStyleSheet("font-family:monospace;color:%s;"
                                    % ("#b00" if leak else "#070"))
        self.statusBar().showMessage("dark reference set by hand", 6000)

    def capture_point(self):
        self._start_capture(False)

    def capture_dark(self):
        if self._start_capture(True):
            self.statusBar().showMessage("measuring dark - LED must be OFF", 4000)

    def _finish_capture(self):
        buf = np.array(self.capture_buf, dtype=float)
        self.capture_buf = None
        self.btn_cap.setEnabled(True)
        self.btn_dark.setEnabled(True)
        self.prog.setValue(0)
        n = len(buf)
        # discard the first 25% - that is the settle
        buf = buf[max(1, n // 4):]
        vA, vB = buf[:, 0], buf[:, 1]

        if self.capture_is_dark:
            gA = float(np.mean(conductance(vA, self.sp["rfa"].value(),
                                           self.sp["vref"].value())))
            gB = float(np.mean(conductance(vB, self.sp["rfb"].value(),
                                           self.sp["vref"].value())))
            self.gd = [gA, gB]
            self.lbl_dark.setText("G_dark  A: %.6g S   B: %.6g S      "
                                  "(V_A %.0f mV, V_B %.0f mV)"
                                  % (gA, gB, np.mean(vA), np.mean(vB)))
            warn = ""
            if np.mean(vA) > 200 or np.mean(vB) > 200:
                warn = "   <-- ABOVE 200 mV: light is leaking in, fix the box first"
                self.lbl_dark.setStyleSheet("font-family:monospace;color:#b00;")
            else:
                self.lbl_dark.setStyleSheet("font-family:monospace;color:#070;")
            self.statusBar().showMessage("dark captured" + warn, 8000)
            return

        eA, eB = self._irr(vA, vB)
        L = log_ratio(eA, eB)
        row = dict(angle=self.capture_angle,
                   vA=float(np.mean(vA)), vB=float(np.mean(vB)),
                   sdvA=float(np.std(vA)), sdvB=float(np.std(vB)),
                   L=float(np.mean(L)), sdL=float(np.std(L)),
                   n=len(buf), note=self.capture_note)
        self._insert(row)
        self.rows.sort(key=lambda r: (r["note"], r["angle"]))
        self._refresh_table()
        self._replot_points()
        if self.chk_auto.isChecked():
            self.spin_angle.setValue(self.spin_angle.value() + self.spin_step.value())
        self.statusBar().showMessage(
            "captured %.1f deg   L=%+.4f   sd=%.4f" % (row["angle"], row["L"], row["sdL"]),
            4000)

    # -- table -------------------------------------------------------------

    def _refresh_table(self):
        self.table.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            for j, val in enumerate(["%.1f" % r["angle"], "%.0f" % r["vA"],
                                     "%.0f" % r["vB"], "%+.4f" % r["L"],
                                     "%.4f" % r["sdL"], r["note"]]):
                self.table.setItem(i, j, QtWidgets.QTableWidgetItem(val))
        self.table.scrollToBottom()

    def delete_row(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            if 0 <= r < len(self.rows):
                del self.rows[r]
        self._refresh_table()
        self._replot_points()

    def clear_rows(self):
        if QtWidgets.QMessageBox.question(
                self, "Clear", "Delete all captured points?") == QtWidgets.QMessageBox.Yes:
            self.rows = []
            self._refresh_table()
            self._replot_points()

    # -- csv ---------------------------------------------------------------

    FIELDS = ["angle", "vA", "vB", "sdvA", "sdvB", "L", "sdL", "n", "note"]

    def save_csv(self):
        if not self.rows:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save CSV", "sweep_%s.csv" % time.strftime("%Y%m%d_%H%M"),
            "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["# vref", self.sp["vref"].value(), "rfa", self.sp["rfa"].value(),
                        "rfb", self.sp["rfb"].value(), "gammaA", self.sp["ga"].value(),
                        "gammaB", self.sp["gb"].value(),
                        "gdA", self.gd[0], "gdB", self.gd[1]])
            w.writerow(self.FIELDS)
            for r in self.rows:
                w.writerow([r[k] for k in self.FIELDS])
        self.statusBar().showMessage("saved %s" % path, 5000)

    def _read_csv(self, path):
        rows = []
        # The "#" line carries the constants the sweep was taken with. Restore
        # them: refitting an old sweep with today's dark reference (or with no
        # dark reference at all) silently changes every E in the file, and the
        # result looks plausible while being wrong.
        with open(path, "r") as fh:
            head = fh.readline()
        if head.startswith("#"):
            f = [t.strip() for t in head.lstrip("# ").split(",")]
            kv = dict(zip(f[0::2], f[1::2]))
            for key, box in (("vref", "vref"), ("rfa", "rfa"), ("rfb", "rfb"),
                             ("gammaA", "ga"), ("gammaB", "gb")):
                try:
                    self.sp[box].setValue(float(kv[key]))
                except (KeyError, ValueError):
                    pass
            try:
                self.gd = [float(kv["gdA"]), float(kv["gdB"])]
                self.lbl_dark.setText("G_dark  A: %.6g S   B: %.6g S      "
                                      "(restored from the file)" % tuple(self.gd))
                self.lbl_dark.setStyleSheet(
                    "font-family:monospace;color:%s;"
                    % ("#070" if any(self.gd) else "#b00"))
            except (KeyError, ValueError):
                pass
        with open(path, "r") as fh:
            for rec in csv.DictReader(
                    (ln for ln in fh if not ln.startswith("#"))):
                try:
                    rows.append(dict(angle=float(rec["angle"]),
                                     vA=float(rec.get("vA", 0)),
                                     vB=float(rec.get("vB", 0)),
                                     sdvA=float(rec.get("sdvA", 0) or 0),
                                     sdvB=float(rec.get("sdvB", 0) or 0),
                                     L=float(rec["L"]),
                                     sdL=float(rec.get("sdL", 0) or 0),
                                     n=int(float(rec.get("n", 1) or 1)),
                                     note=rec.get("note", "")))
                except (KeyError, ValueError):
                    continue
        return rows

    def load_csv(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Load CSV", "", "CSV (*.csv)")
        if not path:
            return
        self.rows = self._read_csv(path)
        self._refresh_table()
        self._replot_points()
        self.statusBar().showMessage("loaded %d points" % len(self.rows), 5000)

    def rezero(self):
        """Shift every angle by a constant.

        Only the zero of the protractor changes, so this is a pure offset on
        the angle column: the voltages, L, the noise and every derived
        quantity are untouched. Use it to move a sweep taken on a 0..180 scale
        onto a -90..+90 one (offset -90), or the other way (+90).
        """
        if not self.rows:
            QtWidgets.QMessageBox.warning(self, "Nothing to re-zero",
                                          "Load or capture a sweep first.")
            return
        old = np.array([r["angle"] for r in self.rows])
        d, ok = QtWidgets.QInputDialog.getDouble(
            self, "Re-zero the angles",
            "Add this to every angle.\n\n"
            "Current sweep spans %.1f to %.1f deg.\n"
            "-90 turns a 0..180 sweep into -90..+90." % (old.min(), old.max()),
            -90.0, -360.0, 360.0, 1)
        if not ok or d == 0.0:
            return
        for r in self.rows:
            r["angle"] += d
        self.spin_bore.setValue(self.spin_bore.value() + d)
        self.spin_angle.setValue(self.spin_angle.value() + d)
        self._refresh_table()
        self._replot_points()
        self.statusBar().showMessage(
            "re-zeroed by %+.1f deg - sweep now spans %.1f to %.1f, boresight %.1f"
            % (d, old.min() + d, old.max() + d, self.spin_bore.value()), 9000)

    def add_overlay(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Add sweep as overlay", "", "CSV (*.csv)")
        if not path:
            return
        rows = self._read_csv(path)
        if not rows:
            return
        label = os.path.splitext(os.path.basename(path))[0]
        self.overlays.append((label,
                              np.array([r["angle"] for r in rows]),
                              np.array([r["L"] for r in rows])))
        self._replot_points()

    # -- plotting ----------------------------------------------------------

    def _groups(self):
        out = {}
        for r in self.rows:
            out.setdefault(r["note"], []).append(r)
        return out

    def _replot_points(self):
        self.p_resp.clear()
        self.p_curve.clear()
        self.p_cmp.clear()
        if self.rows:
            th = np.array([r["angle"] for r in self.rows])
            vA = np.array([r["vA"] for r in self.rows])
            vB = np.array([r["vB"] for r in self.rows])
            eA, eB = self._irr(vA, vB)
            s = max(eA.max(), eB.max()) or 1.0
            o = np.argsort(th)
            self.p_resp.plot(th[o], (eA / s)[o], pen=PEN_A, symbol="o", symbolSize=6,
                             symbolBrush="#0b6fb8", name="cell A")
            self.p_resp.plot(th[o], (eB / s)[o], pen=PEN_B, symbol="s", symbolSize=6,
                             symbolBrush="#c1440e", name="cell B")

            for i, (label, rows) in enumerate(sorted(self._groups().items())):
                a = np.array([r["angle"] for r in rows])
                l = np.array([r["L"] for r in rows])
                o = np.argsort(a)
                pen = pg.mkPen(OVERLAY_PENS[i % len(OVERLAY_PENS)], width=2)
                self.p_curve.plot(a[o], l[o], pen=pen, symbol="o", symbolSize=6,
                                  name=label or "points")
                self.p_cmp.plot(a[o], l[o], pen=pen, symbol="o", symbolSize=5,
                                name=label or "points")
            self.p_curve.addLine(y=0, pen=PEN_GRAY)
            self.p_curve.addLine(x=self.spin_bore.value(), pen=PEN_GRAY)

        for i, (label, a, l) in enumerate(self.overlays):
            pen = pg.mkPen(OVERLAY_PENS[(i + 2) % len(OVERLAY_PENS)],
                           width=2, style=QtCore.Qt.DashLine)
            o = np.argsort(a)
            self.p_cmp.plot(a[o], l[o], pen=pen, symbol="t", symbolSize=5, name=label)

    def _tick(self):
        if not self.live:
            return
        arr = np.array(self.live, dtype=float)
        self.p_live.clear()
        self.p_live.plot(arr[:, 0], arr[:, 3], pen=PEN_FIT)
        if len(arr) > 20:
            recent = arr[-100:, 3]
            self.lbl_status.setText(
                "live  sd(L) over last %d = %.4f    ->  %s"
                % (len(recent), np.std(recent),
                   "quiet" if np.std(recent) < 0.02 else "NOISY - average more"))

    # -- fit ---------------------------------------------------------------

    def do_fit(self):
        pts = [r for r in self.rows]
        if len(pts) < 5:
            QtWidgets.QMessageBox.warning(self, "Not enough points",
                                          "Capture at least 5 angles first.")
            return
        # average duplicate angles across labels
        by_angle = {}
        for r in pts:
            by_angle.setdefault(round(r["angle"], 3), []).append(r)
        th = np.array(sorted(by_angle))
        L = np.array([np.mean([r["L"] for r in by_angle[a]]) for a in th])
        sd = np.array([np.mean([r["sdL"] for r in by_angle[a]]) or 0.0 for a in th])
        sigma_L = float(np.median(sd[sd > 0])) if np.any(sd > 0) else 0.01

        # ------------------------------------------------------------------
        # The ratio zone is where BOTH cells are genuinely lit. Monotonicity
        # alone is not enough: on the floor L is pure noise, and noise is
        # monotone often enough to win the longest-run contest and drag the
        # zone out into the dead band, where it then eats most of the table's
        # rows. Each cell gets its own threshold - see cell_dark_threshold.
        # ------------------------------------------------------------------
        vA_all = np.array([np.mean([r["vA"] for r in by_angle[a]]) for a in th])
        vB_all = np.array([np.mean([r["vB"] for r in by_angle[a]]) for a in th])
        eA_all, eB_all = self._irr(vA_all, vB_all)
        edge_a, floor_a, litA = cell_dark_threshold(eA_all)
        edge_b, floor_b, litB = cell_dark_threshold(eB_all)
        both_lit = litA & litB

        # Backstop: a point whose per-sample scatter is orders above the quiet
        # median is not carrying an angle whatever the light levels say. This
        # rarely fires once the darkness test is right, and it is cheap.
        quiet = np.ones(len(th), bool)
        if both_lit.sum() >= 3 and np.any(sd[both_lit] > 0):
            med = float(np.median(sd[both_lit][sd[both_lit] > 0]))
            if med > 0:
                quiet = sd <= NOISE_K * med
        valid = both_lit & quiet
        span, (a0, a1) = longest_monotone_span(th, L, valid)
        if span <= 0:      # fall back to the old heuristic, then to raw L
            alt = ~(floored_mask(np.log(np.maximum(eA_all, GMIN)))
                    | floored_mask(np.log(np.maximum(eB_all, GMIN))))
            span, (a0, a1) = longest_monotone_span(th, L, alt)
        if span <= 0:
            span, (a0, a1) = longest_monotone_span(th, L)
        bad = span < (th[-1] - th[0]) - 1e-6
        keep = (th >= a0 - 1e-9) & (th <= a1 + 1e-9)
        thm, Lm = th[keep], L[keep]
        if len(thm) < 4:
            QtWidgets.QMessageBox.warning(
                self, "Not monotone",
                "The curve reverses; no lookup table can be built. Re-measure, "
                "or narrow the range.")
            return

        bore = self.spin_bore.value()
        curve0 = MonotoneCurve(thm, Lm)
        lnk = float(curve0.L_of(bore)) if thm[0] <= bore <= thm[-1] else 0.0
        curve = MonotoneCurve(thm, Lm - lnk)
        self.last_curve = curve

        n_rows = self.spin_rows.value()
        L0, dL, table, Lgrid = build_lut(curve, n_rows)
        self.last_lut = (L0, dL, table)

        # metrics.  Noise is strongly angle dependent - a cell that is nearly
        # dark has huge relative noise - so use the sd measured AT EACH ANGLE,
        # never one global number.
        sdm = sd[keep]
        sd_floor = max(1e-4, float(np.percentile(sdm[sdm > 0], 10))
                       if np.any(sdm > 0) else 1e-3)
        sdm = np.maximum(sdm, sd_floor)

        def sd_at(x):
            return np.interp(x, thm, sdm)

        dense = np.linspace(thm[0], thm[-1], 901)
        res = sd_at(dense) / np.maximum(np.abs(curve.dLdtheta(dense)), 1e-9)
        slope_bore = float(np.abs(curve.dLdtheta(np.array([bore]))[0])) \
            if thm[0] <= bore <= thm[-1] else float("nan")
        res_bore = float(sd_at(bore)) / slope_bore \
            if slope_bore == slope_bore else float("nan")
        sigma_rows = np.clip(
            sd_at(table) / np.maximum(np.abs(curve.dLdtheta(table)), 1e-9), 0.005, 99.0)

        # ------------------------------------------------------------------
        # amplitude branch.  Where one cell is geometrically dark the ratio
        # saturates and carries no angle at all, but the LIT cell's own level
        # still moves - steeply, because it is out on the shoulder of its
        # cosine.  Calibrate that as a second, brightness-dependent estimator
        # and let the firmware fall back to it outside the ratio zone.
        # ------------------------------------------------------------------
        sdvA = np.array([np.mean([r.get("sdvA", 0.0) for r in by_angle[a]]) for a in th])
        sdvB = np.array([np.mean([r.get("sdvB", 0.0) for r in by_angle[a]]) for a in th])
        lnS = np.log(np.maximum(eA_all + eB_all, GMIN))
        sum_rows = np.interp(table, th, lnS)

        sdlnA = sd_ln_irradiance(vA_all, sdvA, self.sp["rfa"].value(),
                                 self.sp["vref"].value(), self.gd[0],
                                 self.sp["ga"].value())
        sdlnB = sd_ln_irradiance(vB_all, sdvB, self.sp["rfb"].value(),
                                 self.sp["vref"].value(), self.gd[1],
                                 self.sp["gb"].value())

        # A cell that is geometrically dark sits at a flat stray-light floor, and
        # L then FOLDS BACK into the table's range - so "L outside the table" is
        # not a usable test for the ends. The honest test is that one cell has
        # dropped to ITS OWN floor; those thresholds were derived above, when the
        # zone was found, so the zone and the run-time branch test agree by
        # construction.
        e_edge = float(np.sqrt(max(edge_a, GMIN) * max(edge_b, GMIN)))
        marg_a = edge_a / max(floor_a, GMIN)
        marg_b = edge_b / max(floor_b, GMIN)
        head_a = (float(np.min(eA_all[litA])) / edge_a) if litA.any() else 0.0
        head_b = (float(np.min(eB_all[litB])) / edge_b) if litB.any() else 0.0

        amp = {}          # "lo" / "hi" = the LOW-angle / HIGH-angle end
        amp_report = []
        n_amp = max(8, min(64, n_rows))
        # Overlap each amplitude fit a little way INTO the ratio zone, so a
        # reading that hands over near the boundary lands on real table rows
        # instead of clipping at the very last one.
        step = float(np.median(np.diff(th))) if len(th) > 2 else 5.0
        ov = 1.6 * step
        ends = [(th <= a0 + ov, "low angles", "lo", a0),
                (th >= a1 - ov, "high angles", "hi", a1)]
        for mask, what, key, bound in ends:
            if mask.sum() < 3:
                amp_report.append("  %-12s only %d points - sweep this end at a "
                                  "finer step" % (what, int(mask.sum())))
                continue
            ta = th[mask]
            if (ta.max() - ta.min()) < 2.0:
                continue
            ch = 0 if np.mean(eA_all[mask]) >= np.mean(eB_all[mask]) else 1
            e = (eA_all if ch == 0 else eB_all)[mask]
            sdln = (sdlnA if ch == 0 else sdlnB)[mask]
            x = np.log(np.maximum(e, GMIN))
            sp, (b0, b1) = longest_monotone_span(ta, x)
            k = (ta >= b0 - 1e-9) & (ta <= b1 + 1e-9)
            if k.sum() < 3 or (ta[k].max() - ta[k].min()) < 2.0:
                amp_report.append("  %-12s cell %s level is not monotone - no fallback"
                                  % (what, "AB"[ch]))
                continue
            # Trim from the INNER side only. The level signal is steepest at
            # the far end of the arc, where the source is most oblique to the
            # lit cell, and dies as it swings back toward that cell's own
            # normal - so the outermost point is always the one to keep, and
            # the flat inner tail is the part worth dropping. Trimming from
            # both sides (or by a fraction of the peak slope) is what leaves
            # the sweep's own end uncovered.
            ac = MonotoneCurve(ta[k], x[k])
            idx = np.where(k)[0]
            sl0 = np.abs(ac.dLdtheta(ta[k]))
            order = idx[::-1] if key == "hi" else idx        # outermost first
            slo = sl0[::-1] if key == "hi" else sl0
            keep = list(order[:1])
            for j in range(1, len(order)):
                if slo[j] < AMP_SLOPE_MIN and len(keep) >= 3:
                    break
                keep.append(order[j])
            # ...but never trim short of the ratio zone, or nothing estimates
            # the handover region at all. Covering it with a weak table and
            # saying so beats leaving a hole that reads as a hard clamp.
            weak = 0
            if bound is not None:
                need = (ta >= bound - 1e-9) if key == "hi" else (ta <= bound + 1e-9)
                for j in idx:
                    if need[j] and j not in keep:
                        keep.append(j)
                        weak += 1
            keep = np.array(sorted(set(int(j) for j in keep)))
            k = np.zeros(len(ta), bool)
            k[keep] = True
            if k.sum() < 3 or (ta[k].max() - ta[k].min()) < 2.0:
                amp_report.append("  %-12s cell %s level flattens out - no usable "
                                  "fallback" % (what, "AB"[ch]))
                continue
            ac = MonotoneCurve(ta[k], x[k])
            x0, dx, atab, _ = build_lut(ac, n_amp)
            amp[key] = dict(ch=ch, x0=x0, dx=dx, tab=atab,
                            lo=float(min(atab)), hi=float(max(atab)))
            # Quote the numbers for the sector this table is actually asked to
            # answer - the part OUTSIDE the ratio zone. The overlap into the
            # zone exists so the handover lands on real rows; the ratio branch
            # owns it, and quoting its flat slope would libel the table.
            tk = ta[k]
            served = (tk >= bound - 1e-9) if key == "hi" else (tk <= bound + 1e-9)
            if served.sum() < 2:
                served = np.ones(len(tk), bool)
            slope = np.abs(ac.dLdtheta(tk))
            sdl = np.maximum(sdln[k], 1e-5)
            r = (sdl / np.maximum(slope, 1e-9))[served]
            drift = (0.01 / np.maximum(slope, 1e-9))[served]
            fm = lambda v: (">99" if v > 99 else "%.2f" % v)
            amp_report.append(
                "  %-12s cell %s, %.0f..%.0f deg: noise %s deg worst, "
                "%s deg per 1%% brightness drift"
                % (what, "AB"[ch], tk[served].min(), tk[served].max(),
                   fm(float(np.max(r))), fm(float(np.max(drift)))))
            flat = served & (slope < AMP_SLOPE_MIN)
            if flat.any():
                amp_report.append(
                    "     ^ %.0f..%.0f deg of that is nearly flat (%s deg per 1%%) - "
                    "this is the weak sector; re-sweep it at 1 deg"
                    % (tk[flat].min(), tk[flat].max(),
                       fm(float(np.max((0.01 / np.maximum(slope, 1e-9))[flat])))))
        self.last_amp = amp

        # residuals: fit and full firmware round trip
        fit_at_pts = curve.L_of(thm)
        resid_deg = (Lm - lnk - fit_at_pts) / np.maximum(
            np.abs(curve.dLdtheta(thm)), 1e-9)
        rt = lut_lookup(L0, dL, table, curve.L_of(dense)) - dense

        # plots
        self.p_curve.clear()
        self.p_curve.plot(thm, Lm - lnk, pen=None, symbol="o", symbolSize=7,
                          symbolBrush="#0b6fb8", name="measured")
        self.p_curve.plot(dense, curve.L_of(dense), pen=PEN_FIT, name="fit")
        self.p_curve.addLine(y=0, pen=PEN_GRAY)
        self.p_curve.addLine(x=bore, pen=PEN_GRAY)

        self.p_res.clear()
        self.p_res.plot(dense, res, pen=PEN_FIT, name="sigma_theta")
        self.p_res.addLine(y=0.5, pen=PEN_GRAY)
        self.p_res.setYRange(0, min(10, float(np.percentile(res, 97)) * 1.2 + 0.1))

        self.p_resid.clear()
        self.p_resid.plot(thm, resid_deg, pen=None, symbol="o", symbolSize=6,
                          symbolBrush="#c1440e", name="point - fit")
        self.p_resid.plot(dense, rt, pen=PEN_A, name="table lookup error")
        self.p_resid.addLine(y=0, pen=PEN_GRAY)

        good = res < 1.0
        good_span = (dense[good].max() - dense[good].min()) if np.any(good) else 0.0

        txt = []
        txt.append("=== fit ===")
        txt.append("points            %d   over %.1f to %.1f deg" % (len(thm), thm[0], thm[-1]))
        if bad:
            txt.append("!! L was NOT monotone over the whole sweep - kept %.0f..%.0f deg only"
                       % (a0, a1))
        txt.append("noise sd(L)       %.4f median,  %.4f worst (at the ends)"
                   % (float(np.median(sdm)), float(np.max(sdm))))
        txt.append("slope at %.0f deg   %.4f  per deg" % (bore, slope_bore))
        txt.append("resolution        %.3f deg at boresight,  %.3f deg median"
                   % (res_bore, float(np.median(res))))
        txt.append("better than 1 deg over %.0f deg  (%.0f..%.0f)"
                   % (good_span, dense[good].min() if np.any(good) else 0,
                      dense[good].max() if np.any(good) else 0))
        txt.append("worst resolution  %.2f deg  (at %.0f deg)"
                   % (float(np.max(res)), float(dense[int(np.argmax(res))])))
        txt.append("table round trip  worst %.3f deg,  rms %.3f deg"
                   % (np.max(np.abs(rt)), float(np.sqrt(np.mean(rt ** 2)))))
        txt.append("fit residual      worst %.3f deg" % np.max(np.abs(resid_deg)))
        txt.append("")
        txt.append("=== ratio zone ===")
        txt.append("both cells lit    %.1f to %.1f deg   <- brightness-immune" % (a0, a1))
        txt.append("cell A  floor E %.3g  dark below %.3g  (x%.1f floor, x%.1f headroom)"
                   % (floor_a, edge_a, marg_a, head_a))
        txt.append("cell B  floor E %.3g  dark below %.3g  (x%.1f floor, x%.1f headroom)"
                   % (floor_b, edge_b, marg_b, head_b))
        if min(head_a, head_b) < 2.0:
            txt.append("!! that headroom is thin - the branch may flip mid-reading. "
                       "Re-sweep the handover at 1 deg.")
        if a0 > th[0] + 1e-9 or a1 < th[-1] - 1e-9:
            txt.append("=== amplitude fallback (outside the ratio zone) ===")
            txt.extend(amp_report or
                       ["  none built - sweep further into the ends, or the level "
                        "is not monotone there"])
            # The ends are only as good as the brightness reference. Spell out
            # what a COLD one costs, because that is the failure people meet:
            # power up, put the source at 170 deg, read a confident wrong number.
            if amp:
                txt.append("--- and what a wrong brightness reference costs ---")
                for key, what in (("lo", "low angles"), ("hi", "high angles")):
                    a = amp.get(key)
                    if not a:
                        continue
                    tab = np.asarray(a["tab"])
                    sl = abs(a["dx"]) / max(abs(np.median(np.diff(tab))), 1e-9)
                    for f, lab in ((1.1, "10% dimmer/brighter"),
                                   (1.5, "1.22x further away")):
                        txt.append("  %-12s source %-20s -> %5.1f deg out"
                                   % (what, lab, np.log(f) / max(sl, 1e-9)))
                txt.append("  warm the reference: park inside %.0f..%.0f deg for 3 s."
                           % (a0, a1))
                txt.append("  firmware >=1.2.0 keeps it across a reboot and shows")
                txt.append("  REF COLD on the OLED until it has one.")
        txt.append("")
        txt.append(self._c_block(lnk, L0, dL, table, sigma_rows, sigma_L,
                                 sum_rows, amp, e_edge, edge_a, edge_b))
        self.txt_out.setPlainText("\n".join(txt))
        self.statusBar().showMessage(
            "fit done - resolution %.3f deg at boresight" % res_bore, 8000)

    def _c_block(self, lnk, L0, dL, table, sigma_rows, sigma_L,
                 sum_rows=None, amp=None, e_edge=0.0,
                 e_edge_a=None, e_edge_b=None):
        eAmin = None
        try:
            va = np.array([r["vA"] for r in self.rows])
            vb = np.array([r["vB"] for r in self.rows])
            ea, eb = self._irr(va, vb)
            eAmin = float(np.min(ea + eb)) * 0.25
        except Exception:
            eAmin = 0.0
        lines = []
        ap = lines.append
        ap("/* ---------- calib.h : generated %s ---------- */"
           % time.strftime("%Y-%m-%d %H:%M"))
        ap("/* paste over the block in calib.h, then re-upload           */")
        ap('#define CAL_LABEL     "%s"' % (self.edit_note.text().strip() or "run"))
        ap("#define CAL_VREF_MV   %.1ff" % self.sp["vref"].value())
        ap("#define CAL_RF_A      %.1ff" % self.sp["rfa"].value())
        ap("#define CAL_RF_B      %.1ff" % self.sp["rfb"].value())
        ap("#define CAL_GD_A      %s" % cfloat(self.gd[0]))
        ap("#define CAL_GD_B      %s" % cfloat(self.gd[1]))
        ap("#define CAL_GAMMA_A   %.4ff" % self.sp["ga"].value())
        ap("#define CAL_GAMMA_B   %.4ff" % self.sp["gb"].value())
        ap("#define CAL_LNK       %.6ff" % lnk)
        ap("#define CAL_L0        %.6ff" % L0)
        ap("#define CAL_DL        %.6ff" % dL)
        ap("#define CAL_N         %d" % len(table))
        ap("#define CAL_L1        %.6ff" % (L0 + dL * (len(table) - 1)))
        ap("#define CAL_SIGMA_L   %.6ff" % sigma_L)
        ap("#define CAL_MIN_E     %s" % cfloat(eAmin, "%.6g"))
        # The OLED position bar spans everything the board can REPORT, which
        # includes the two level tables - not just the ratio zone, or the bar
        # pegs at both ends for a third of the arc.
        a_lo, a_hi = float(min(table)), float(max(table))
        for a in (amp or {}).values():
            a_lo = min(a_lo, float(min(a["tab"])))
            a_hi = max(a_hi, float(max(a["tab"])))
        ap("#define CAL_ANG_MIN   %.2ff" % a_lo)
        ap("#define CAL_ANG_MAX   %.2ff" % a_hi)
        ap("/* angle for each table row, rows are evenly spaced in L */")
        ap("static const float CAL_THETA[CAL_N] = {")
        for i in range(0, len(table), 6):
            ap("  " + ", ".join("%9.4ff" % v for v in table[i:i + 6]) + ",")
        ap("};")
        ap("/* expected 1-sigma uncertainty at each row, degrees */")
        ap("static const float CAL_SIGMA[CAL_N] = {")
        for i in range(0, len(sigma_rows), 6):
            ap("  " + ", ".join("%9.4ff" % v for v in sigma_rows[i:i + 6]) + ",")
        ap("};")
        def arr(name, n, vals, fmt="%9.4ff"):
            ap("static const float %s[%s] = {" % (name, n))
            for i in range(0, len(vals), 6):
                ap("  " + ", ".join(fmt % v for v in vals[i:i + 6]) + ",")
            ap("};")

        if sum_rows is not None:
            ap("/* expected ln(E_A+E_B) at each row - tracks LED brightness */")
            arr("CAL_SUM", "CAL_N", sum_rows, "%10.5ff")
        else:
            ap("static const float CAL_SUM[1] = { 0.0f };")

        ap("/* darkness thresholds - ONE PER CELL. The two cells sit at very")
        ap("   different stray-light floors, so a single shared number is")
        ap("   above one cell's floor and below the other's, and the cell with")
        ap("   the higher floor is never seen to go dark at all. */")
        ap("#define CAL_E_EDGE_A  %s   /* cell A below this is dark */"
           % cfloat(e_edge if e_edge_a is None else e_edge_a, "%.6g"))
        ap("#define CAL_E_EDGE_B  %s   /* cell B below this is dark */"
           % cfloat(e_edge if e_edge_b is None else e_edge_b, "%.6g"))
        ap("#define CAL_E_EDGE    %s   /* geometric mean, for older firmware */"
           % cfloat(e_edge, "%.6g"))
        for key, tag in (("lo", "AL"), ("hi", "AH")):
            a = (amp or {}).get(key)
            ap("/* amplitude fallback for the %s-angle end */"
               % ("low" if key == "lo" else "high"))
            if a is None:
                ap("#define CAL_%s_N      0" % tag)
                ap("#define CAL_%s_CH     0" % tag)
                ap("#define CAL_%s_X0     0.0f" % tag)
                ap("#define CAL_%s_DX     1.0f" % tag)
                ap("static const float CAL_%s_TH[1] = { 0.0f };" % tag)
            else:
                ap("#define CAL_%s_N      %d" % (tag, len(a["tab"])))
                ap("#define CAL_%s_CH     %d   /* 0 = cell A, 1 = cell B */"
                   % (tag, a["ch"]))
                ap("#define CAL_%s_X0     %.6ff" % (tag, a["x0"]))
                ap("#define CAL_%s_DX     %.6ff" % (tag, a["dx"]))
                arr("CAL_%s_TH" % tag, "CAL_%s_N" % tag, a["tab"])
        ap("/* ------------------------------------------------------- */")
        return "\n".join(lines)

    HEADER_TOP = """// =====================================================================
//  calib.h  -  generated by comp_gui.py.  Overwrite this whole file.
//
//  Everything above the dashed line is boilerplate; everything between the
//  dashed lines is the calibration. Re-upload after saving.
// =====================================================================
#pragma once

"""

    def _c_only(self):
        """Just the C block - never the fit summary above it."""
        body = self.txt_out.toPlainText()
        i = body.find("/* ---------- calib.h")
        return body[i:] if i >= 0 else ""

    def copy_out(self):
        block = self._c_only()
        if not block:
            self.statusBar().showMessage("nothing generated yet - press FIT first", 4000)
            return
        QtWidgets.QApplication.clipboard().setText(block)
        self.statusBar().showMessage(
            "C block copied (the fit summary is NOT included)", 5000)

    def save_h(self):
        block = self._c_only()
        if not block:
            self.statusBar().showMessage("nothing generated yet - press FIT first", 4000)
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Overwrite firmware/comp_sensor/calib.h", "calib.h", "Header (*.h)")
        if not path:
            return
        with open(path, "w") as fh:
            fh.write(self.HEADER_TOP)
            fh.write(block)
            fh.write("\n")
        self.statusBar().showMessage(
            "wrote %s  -  now re-upload the firmware" % path, 9000)

    def closeEvent(self, ev):
        if self.reader:
            self.reader.stop()
        ev.accept()


def main():
    app = QtWidgets.QApplication(sys.argv)
    w = Main()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
