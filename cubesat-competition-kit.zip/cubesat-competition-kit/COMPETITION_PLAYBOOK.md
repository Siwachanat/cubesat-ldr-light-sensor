# Competition playbook — fixed ±20° LDR pair, designable centre blade

Tickable, self-timing version (checkboxes and the clock persist in the browser):
https://claude.ai/code/artifact/9fc5b3ee-13b1-41a9-82e7-f7dab0af2192

**Once the baffle is cut and aligned**, follow the calibration run card instead —
it is steps 6–10 below at click-by-click detail, with the numbers to expect at
every stage: https://claude.ai/code/artifact/c2e3cfd6-c61d-46cb-a351-4d8fe0e8fa9e

Replaces the diffuser-cylinder plan in `baffle-design-v1.md` for this event:
the organisers supply the head with both LDRs already mounted, so the cell
orientation is no longer ours to choose. What remains ours is the blade
between them, the electronics, the calibration and the estimator.

**Confirmed constraints for this event**

| | |
|---|---|
| Cells | fixed, splayed ≈20° per side outward (≈40° between the faces) |
| Buildable | the centre blade only — shape, height and material are ours |
| Range | full 0–180° on the protractor is scored |
| Motion | none — the head is fixed, the organisers move the LED |
| Data | collected by hand, one point per protractor mark |
| Allowed | a laptop with a Python GUI for capture, plotting and fitting |
| Loading | paste the generated C block into `calib.h`, re-upload |
| Hardware | SunSeek v1.3 (ESP32-S3), LDRs on io17 / io16, I²C OLED |

---

## 0. The four facts that decide everything

1. **The ratio can only work over 20°–160°, and no blade changes that.**
   A cosine cell is dark once the source is more than 90° off its own normal.
   Splayed 20° outward, cell A dies at 160° on the protractor and cell B at
   20°. Outside that band one cell sees nothing but stray light, so the ratio
   carries no angle at all. This is geometry, not build quality.

2. **So the ends get a second estimator, not a shrug.** Where one cell is
   dark, the *lit* cell's own level still moves — steeply, because it is out
   on the shoulder of its cosine (`d lnE/dθ = tan(θ−70°)`, about 0.048 per
   degree at 0°, three times the ratio's slope at boresight). That branch is
   not brightness-immune, so the firmware continuously re-references LED
   brightness from `ln(E_A+E_B)` while it is inside the ratio zone and carries
   that reference into the ends. Simulated: 0.04° of noise there, and 0.5°
   after a ±60 % change in LED brightness — against 12–18° with no reference.

3. **The gap between blade and cell matters more than the blade's height.**
   Inside `±arctan(g/h)` the blade's shadow has not reached the cell yet and
   only the weak `tan β` term works. With the 0.4 mm epoxy rim as the gap, a
   1.5 mm blade is blind over ±13° and boresight resolution stays at 0.34°
   whatever the height. Fold the blade's tabs hard against the domes to close
   `g`, and 0.34° becomes 0.23° — a bigger win than any height change.

4. **The table absorbs the constants.** Built on `L = ln E_A − ln E_B − ln k`,
   every *multiplicative* constant — `R_F`, `V_REF`, `γ`, `k` — is only an
   additive offset and cancels. The two things that do **not** cancel are the
   **dark subtraction** (it is subtracted, not divided) and the **geometry**.

### Blade height — measured on our own head, 2026-09-07

Three sweeps at h = 6, 15 and 30 mm (`data/sweep_h*.csv`) fix every constant.
Full working, with charts: `claude/blade-height-sweep-results` artifact
https://claude.ai/code/artifact/8f9fe785-398d-4d7f-96bf-b61a06ba9267

| Quantity | Value | How |
|---|---|---|
| cell window `g + w` | **5.42 mm** ±0.09 | `h·tan θ_sat` at three heights: 5.50, 5.46, 5.29 |
| splay `β` | **±18.2°** | cosine fit per cell, normals at 80.9° and 117.4° |
| optical boresight | **99.1°** | midpoint of the two normals |
| blade plane, as built | **93.3°** | midpoint of the two shadow edges — 5.8° off boresight |
| **blade to cut** | **1.8 mm** | `h = (g+w)/tan(90−β) = 5.42/tan 71.75°` |

| h (mm) | θ_sat | ratio zone (blade centred) | width | dead band |
|---|---|---|---|---|
| 30 | 10.2° | 89–109° | 20° | ±0.8° |
| 15 | 19.9° | 79–119° | 40° | ±1.5° |
| 6 | 42.1° | 57–141° | 84° | ±3.8° |
| 3 | 61.0° | 38–160° | 122° | ±7.6° |
| **1.8** | **71.6°** | **27–171°** | **144°** | **±12.5°** |

**Cut 1.8 mm and slide the blade onto the boresight.** Below 1.8 mm the cells,
not the blade, are the limit — nothing more to gain. Resolution at boresight is
`σ_L / (2 tan β)` = **0.50°** whatever you cut, because the dead band means the
blade does nothing there; everywhere else is 0.1–0.3°.

*Optional, home bench only:* a **white** blade scatters one-sidedly — it only
ever brightens the cell on the source's own side — so it adds contrast where
the shadow term is blind. Modelled at about 8–10 % more slope at boresight for
no range cost. Cheap to A/B with the GUI's Compare tab; do not adopt it
untested, because a white blade also throws light at the deck.

---

## 1. Go bag

Cut and pack all of this **before the day**.

**Blades ×4** (sheet 1 of `baffle_templates.pdf`)

- [ ] Matte black card 0.5–1.0 mm, black both faces, 30 mm tall in Z
- [ ] Datum line marked, trim ladder 1.0–6.0 mm intact
- [ ] Fold tabs cut, ready to press against the domes
- [ ] One spare blade in white card, for the optional A/B

**Electronics**

- [ ] SunSeek board, **pre-flashed** with `comp_sensor.ino` (uncalibrated —
      it boots into RAW mode and the OLED says NO CAL)
- [ ] R_F resistors, 1 % metal film: 4.7k, 8.2k, 15k, 22k, 47k — **pairs**
- [ ] 100 nF ×4, spare header wires, USB-C cable ×2
- [ ] Laptop with `comp_gui.py` **already tested**;
      `pip install PyQt5 pyqtgraph pyserial numpy` done offline
- [ ] **Arduino IDE _or_ VS Code + PlatformIO already compiling this sketch** —
      both build the same sources (`firmware/README.md`). Whichever you bring,
      compile it once at home; the venue is not the place to discover a missing
      board package. Bring the other one installed too if the laptop has room.

**Bench**

- [ ] Matte black card, A3, for the deck
- [ ] Black tape, glue stick, scalpel, small square, steel rule, calipers
- [ ] Printed templates, printed fault table, pen and paper for the numbers

---

## 2. Competition day, in order

### Step 1 — Survey the rig · 5 min · **before you touch the head**

| Measure | Why |
|---|---|
| **R**, protractor centre → LED | the calibration is valid at one R |
| The actual splay, sighting from above | if it is not ≈20°, the zone moves |
| LED height, and whether it will change | vertical faces are what make this cancel |
| **Is LED brightness fixed between runs?** | now critical — the ends depend on it |
| Is the box light-tight with the lid on? | a leak is a bias you cannot calibrate out |

**Ask the organisers about the ends.** A ±20° pair cannot produce a
brightness-immune reading at 0–20° or 160–180°; every team has the same
ceiling. Knowing whether those sectors are scored, and whether the LED
brightness is guaranteed constant, tells you how hard to defend the amplitude
branch.

### Step 2 — Fit and trim the blade · 8 min

1. Slide the blade in until the **red datum** is level with the front of the
   epoxy domes.
2. Fold the two tabs back hard against the domes — this is step 3 of §0, worth
   more than any height change.
3. Trim the front edge to the **1.8 mm** ladder line.
4. Check it stands the full height in Z and reaches back past both cells, so
   no light crosses behind it.
5. Slide it sideways until its plane passes through the boresight — see §2a if
   this is a head you have not characterised before.

### Step 2a — If the head is not the one we measured · +15 min

Do not guess `g + w`, `β` or the boresight. One cheap sweep gives all three.

1. Fit a **gauge blade at a height you can measure** — 6 mm puts the shadow
   edges in easy view. Write down what you actually cut.
2. **Dark reading first**, then a **10° sweep** across the whole arc (19 points,
   ~6 min). You are locating features, not calibrating.
3. Read four numbers off the plots:
   - the two **shadow edges** — the grid step where a cell crosses ~8× its floor,
     take the midpoint of that step
   - the two **response peaks** — each cell's own normal
4. Compute:
   ```
   blade plane  φ      = (edge_lo + edge_hi) / 2
   saturation   θ_sat  = (edge_hi − edge_lo) / 2
   window       g + w  = h_gauge · tan θ_sat
   boresight    Θ₀     = (peak_A + peak_B) / 2
   splay        β      = |peak_A − peak_B| / 2
   θ_max = 90° − β        h_final = (g + w) / tan θ_max
   ```
5. **Round h_final down** to the nearest ladder line. Too short costs slope in
   the middle; too tall costs scored range at both ends.
6. Trim, slide the blade onto Θ₀, press the tabs, then do the real 5° sweep.
7. **Check your prediction**: the new ratio zone should land within a couple of
   degrees of `Θ₀ ± arctan((g+w)/h_final)`. If not, the blade moved when you cut
   it — measure it with calipers before doubting the model.

### Step 3 — Align · 8 min · **this is where the degrees are lost**

- Blade in the plane of the **boresight** (99.1° on our head, not 90°), square
  across the baseline. *1° of twist is 1° of bias in every reading.*
- **Squaring the head to 90° is optional.** The zone is 144° wide either way —
  rotating only moves where the loss falls, from 27°/9° to a symmetric 18°/18°.
  Do it if the mount turns freely; skip it if it is bolted down. **Centring the
  blade on the boresight is not optional** — off-centre costs 5.8° of real
  range.
- Head centre over the protractor centre within 1 mm. *1 mm at R = 150 mm is
  0.4°.*
- Cell faces vertical, checked with a small square.
- Matte black card on the deck and over anything shiny within a hand's width.
  Bounce adds to both cells, which divides the ratio down and flattens the
  whole curve.

### Step 4 — Wire and power · 5 min

`3V3 → LDR → node → R_F → GND`, 100 nF at each node. Cell A (faces the 0° end)
→ **io17**, cell B → **io16**. Wi-Fi and Bluetooth stay off — io17/io16 are
ADC2, which the radio steals.

### Step 5 — R_F and the sanity walk · 6 min · LED ON

- Both nodes 1.8–2.6 V with the LED near 90°. Under 0.8 V → R_F too small;
  over 3.0 V → too large. Change **both** channels together.
- Walk the LED 0°→180° watching the **Live** tab. `L` should move smoothly
  one way between about 20° and 160°, and **flatten out** beyond those — that
  flattening is the geometry, not a fault.
- If `L` runs the wrong way, swap the two plugs.

### Step 6 — Dark reference · 3 min · **LED OFF, lid shut**

**Measure DARK.** Both nodes under 200 mV (under 50 in a well-sealed box).
Above 200 mV is a leak: tape it and repeat. This is the one constant the table
cannot absorb.

### Step 7 — The sweep · 15 min · LED ON · **two people**

One person moves the LED and calls the mark; the operator types it and presses
Enter. The caller does not touch the laptop.

Panel 3 has two tabs and they mix freely. **Serial capture** averages a burst of
telemetry per angle. **Manual entry** takes the two cell readings typed in by
hand — in mV or ADC counts, one point at a time or as a pasted block of
`angle A B` rows — so the whole fit still works with no board attached, or from
numbers written on paper. Typed points carry no measured scatter, so set the
"noise mV" box to the per-sample ADC noise you expect (read it off the Live tab
if you can) and the resolution and `CAL_SIGMA` figures stay honest.

- **5° steps over the whole 0°–180°**, label `run1`. All 37 points — the ends
  are not optional now, they are what builds the amplitude tables.
- **Then go back and add 2.5° points over 0–25° and 155–180°.** Those sectors
  carry a whole estimator on about five points each; give them ten.
- Watch the **Curve** tab as you go. `L` folding flat at each end is expected.
  A kink *inside* 20–160° is not — fix it now.
- Repeatability: label `run2`, re-capture 30°, 90°, 150° with the LED taken
  away and brought back each time.

### Step 8 — Fit and load · 5 min

**FIT + GENERATE calib.h**, then read the summary:

| Line | Want | If not |
|---|---|---|
| both cells lit … | ≈20 to ≈160° | much narrower ⇒ blade too tall, or stray light |
| resolution at boresight | < 0.35° | press the blade tabs harder against the domes |
| table round trip worst | < 0.15° | raise LUT rows |
| fit residual worst | < 0.3° | one bad point — find it on Residuals, re-capture |
| amplitude fallback, both ends | present | sweep further into the ends, 2.5° steps |
| … deg per 1 % brightness drift | < 1° | nothing to do; it sets your exposure |

**Copy** → paste over the block in `calib.h` → re-upload. The board reboots
into RUN mode.

### Step 9 — Validate · 12 min

1. **Blind angles in the ratio zone** — 23°, 67°, 142°. Want under 0.5°.
2. **Blind angles in the ends** — 8°, 172°. The OLED will say `amp`. Want
   under 1°.
3. **The handover** — walk slowly through 20° and 160° and watch the reported
   angle. It must not jump. A jump means the branch threshold is wrong; widen
   the 2.5° coverage and refit.
4. **Elevation** — raise the LED 20–30 mm, re-read. Under 0.3° in the ratio
   zone.
5. **Brightness** — dim the LED or move it 30 mm out. In the ratio zone `D`
   must not move. In the ends, let the reading sit inside 20–160° for a few
   seconds first so the firmware re-references brightness, then move to the
   end and read. Compare against reading the end *without* that warm-up.
6. **Repeat** — same mark three times, LED removed and replaced. That spread
   is your real error bar.

Write all six results on paper.

### Step 10 — Freeze

Save the CSV and the generated `calib.h` to two places. Do not touch the head,
the deck, the LED distance, or the code again.

---

## 3. Home practice — three sessions

**Session 1 (~2 h) — make the chain work once.** Mock the fixed head: two LDRs
glued to a scrap of card at 20° each side of a centre line, blade between.
Run the whole thing on your own protractor. Confirm the GUI finds a ratio zone
near 20–160° and builds both amplitude tables.

**Session 2 (~2 h) — the timed dry run.** Venue conditions: blades in the bag,
board flashed uncalibrated, laptop closed. Run steps 1–10 against the clock,
same two people in the same two roles. The stamps are your real schedule.

**Session 3 (~1 h) — failure drills and the blade A/B.** Half the hour on
faults: light leak, swapped plugs, wrong R_F, blade twisted 5°, tabs not
touching the domes, deck card removed — diagnose each in under two minutes.
The other half sweeping 1.5 mm black, 1.5 mm white and 3.0 mm black, loading
all three into the Compare tab and keeping the winner.

---

## 4. Fault table

| Symptom | Cause | Fix |
|---|---|---|
| ratio zone much narrower than 20–160° | blade too tall, or stray light | trim to 1.5 mm; black card on the deck |
| ratio zone wider than 20–160° | splay is smaller than 20° | fine — re-measure β and note it |
| boresight resolution stuck near 0.34° | tabs not touching the domes | press them onto the epoxy; that gap is the whole cause |
| `L` reverses *inside* 20–160° | stray light on the shadowed cell | deck card, lid shut, re-sweep |
| curve flatter than practice | deck bounce | same |
| one channel pinned near 0 V | R_F too small, or open LDR | next E12 up, **both** channels |
| one channel pinned near 3.3 V | R_F too large, or shorted LDR | next E12 down, both channels |
| dark reading over 200 mV | light leak | tape the seams; never calibrate around it |
| angle runs backwards | A and B swapped | swap the two plugs, re-sweep |
| reported angle jumps at 20° or 160° | branch threshold off | add 2.5° points either side of the handover, refit |
| ends read badly after the LED was changed | brightness reference stale | park inside 20–160° for a few seconds, or send `AMPRESET` and re-park |
| OLED shows `amp` in the middle of the range | a cell is below `CAL_E_EDGE` — usually a leak or a dead channel | check `RAW`; if a channel is dark, it is a wiring fault |
| OLED shows `edge+` / `edge-` | outside everything the calibration covers | not a measurement — say so |
| laptop cannot see the serial port | driver, cable, or a busy port | do not lose the slot: switch panel 3 to **Manual entry**, read the OLED RAW page and type the two numbers per angle. Type the dark reading in beside the DARK button |
| serial port opens but no banner | wrong USB CDC setting | Arduino IDE: flip *USB CDC On Boot*. PlatformIO: switch env between `esp32s3_uart` and `esp32s3_usb`. Same decision, two names |
| `'ADC_ATTEN_DB_12' was not declared` | a core-3.x-only enum spelling | use `ADC_11db`, which every core has. There is no `#ifdef` that can choose between them — enum constants are not macros — so the sketch just uses the universal name |
| sketch will not compile: `'Meas' does not name a type` | a type used in a signature was moved into the .ino | it belongs in `config.h` — the IDE hoists prototypes above the sketch body. Run `python3 tests/check_compile.py` to catch this without the ESP32 toolchain |
| OLED blank, "not found" | wrong I²C pins | read the scan line, set `OLED_SDA/SCL`, `OLED_AUTOSCAN 0` |
| judge moves the LED distance | parallax, and the amplitude branch shifts | the ratio zone barely moves; the ends will be wrong until the reference re-settles |

---

## 5. Why the algorithm is what it is

**Statistic.** `L = ln(E_A/(k·E_B))`, with `E = (1/R_LDR − G_dark)^(1/γ)` and
`R_LDR = R_F(V_REF/V − 1)`. Dark leakage is removed as a *conductance* because
that is the term that adds in parallel. `L` rather than
`D = (E_A−E_B)/(E_A+E_B)` because `D` saturates at ±1 while `L` does not — and
`D = tanh(L/2)`, so they carry identical information.

**Inversion.** A calibrated lookup table, never the analytic formula. The
model ignores near-field parallax, cell mismatch, the epoxy dead band, deck
bounce and a γ that is only nominally 0.7; the naive `atan(D/tanβ)` came out
**14° wrong at a true 30°** on this class of head. One sweep absorbs all of it.

**Table shape.** Rows evenly spaced **in L**, not in angle. That equalises the
interpolation error and lets the firmware index directly — `i = (L − L0)/dL`,
no search. **128 rows** is the default: at 64 the table's own interpolation
(0.31° worst on the measured head) was the largest error in the middle of the
arc, larger than the noise it was carrying. 128 rows takes that to 0.11° and
costs 1.5 kB of flash.

**Two regimes, and how the firmware chooses.** Not by where `L` landed —
that is the trap. Once a cell drops to its stray-light floor, `L` *folds back*
into the table's own range and a 3° reading would be reported as a perfectly
plausible 22°. The honest test is absolute: a cell below its own darkness
threshold is dark, and that threshold is scaled by the tracked brightness so it
still works when the LED is dimmer or brighter than it was at calibration.

Two details of that test were wrong until firmware 1.1.0, and both cost the
outer sectors entirely:

- **One threshold per cell, not one shared.** `CAL_E_EDGE_A` and
  `CAL_E_EDGE_B`. On a real deck the two cells sit an order of magnitude apart
  in stray light, and a shared number is then above one floor and below the
  other — so the cell with the higher floor is never seen to go dark and its
  half of the arc never reaches the level table.
- **Falling off the end of the table also disqualifies the ratio.** Both cells
  can be lit while `L` is past the last row. Keep the ratio answer only when
  the lookup was in range *and* both cells are lit; anything else falls
  through to the level branch.

The two tests catch different failures and you need both: darkness catches the
fold, range catches the handover.

**Uncertainty.** Noise is strongly angle-dependent, so the GUI measures the
scatter **at each angle** and ships `CAL_SIGMA[]` alongside the angles. The
OLED shows `87.4 ±0.11` in the ratio zone, and `level branch` in the ends,
where the honest error bar is dominated by brightness stability rather than
noise.

---

## 6. Serial commands (115200, newline)

```
ID                  banner, version, calibration label, amplitude table sizes
GET                 settings, table sizes, current brightness reference
MODE RAW | RUN      collecting  /  competition display
AVG  <1..1024>      ADC reads per sample      (default 64, raise if noisy)
RATE <1..100>       telemetry lines per second (default 20)
SMOOTH <0..0.9>     display smoothing only     (default 0.25)
AMPRESET            forget the tracked brightness and re-learn it
HOLD 0|1            freeze the displayed angle
```

Telemetry: `T,<ms>,<vA_mV>,<vB_mV>,<L>,<D>,<angle>,<sigma>,<status>`.
The GUI reads only the two voltages; every other field is for you.
