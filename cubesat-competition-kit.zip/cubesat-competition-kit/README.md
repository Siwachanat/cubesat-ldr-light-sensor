# Competition kit — fixed ±20° LDR pair, designable centre blade

The organisers supply the head with both LDRs mounted and splayed ≈20° outward.
The blade between them is the only part you build.

| File | What it is |
|---|---|
| `COMPETITION_PLAYBOOK.md` | practice method + the day-of procedure, blade-height trade, fault table, why the algorithm is what it is |
| `baffle_templates.pdf` | 1:1 blade blanks with a datum and a trim ladder, the plan-view geometry sheet, and a practice protractor. **Print at 100%** and check the 100 mm bar |
| `comp_gui.py` | PyQt5 console: capture over serial **or type readings in by hand**, plot, fit, generate `calib.h` |
| `firmware/` | ESP32-S3 firmware, buildable from **either** the Arduino IDE or VS Code + PlatformIO — one copy of the source, two toolchains. See `firmware/README.md`. `calib.h` is the only file you edit on the day |
| `make_templates.py` | regenerates the PDF if the blade dimensions change |
| `tests/` | the simulated-head checks used to verify all of the above, plus `check_compile.py`, which compiles the sketch the way the Arduino IDE does (prototypes hoisted) without needing the ESP32 toolchain |

## The two facts that shape everything

**The ratio only works over 20°–160°.** A cosine cell is dark past 90° off its
own normal, so with a 20° splay cell A dies at 160° and cell B at 20°. No blade
changes that.

**The ends get a second estimator.** Where one cell is dark the lit one is out
on the shoulder of its cosine and still moves steeply. That branch is not
brightness-immune, so the firmware tracks LED brightness from `ln(E_A+E_B)`
while inside the ratio zone and carries the reference into the ends. Readings
from it are flagged `amp` on the OLED.

## Laptop setup (at home, offline-capable afterwards)

```
pip install PyQt5 pyqtgraph pyserial numpy
python comp_gui.py
```

Firmware, whichever you prefer — both build the same files:

- **Arduino IDE**: ESP32 board package plus **Adafruit SSD1306** and **Adafruit
  GFX**. Open `firmware/comp_sensor/comp_sensor.ino`, board = ESP32S3 Dev
  Module, set *USB CDC On Boot* to match your port, upload.
- **VS Code + PlatformIO**: open the **`firmware/`** folder. Pick
  `esp32s3_uart` (bridge port, default) or `esp32s3_usb` (native USB). Build,
  upload, monitor.

`platformio.ini` sets `src_dir = comp_sensor`, so PlatformIO compiles the same
sketch the Arduino IDE opens — there is no second copy to drift.
`tests/check_compile.py` enforces that.

Either way it boots into RAW mode with `CAL_N 0` and the OLED says NO CAL —
correct for an uncalibrated board.

## The loop on the day

1. Fit the blade, datum level with the domes, tabs pressed onto the epoxy,
   trimmed to the 1.5 mm ladder line. Align.
2. `comp_gui.py` → Connect → **Measure DARK** with the LED off.
3. LED on. 5° steps across the whole 0–180°, then 2.5° over 0–25° and 155–180°.
   Panel 3 has two tabs: **Serial capture** averages a burst per angle from the
   board; **Manual entry** lets you type cell A and cell B yourself in mV or ADC
   counts, one point at a time or as a pasted block of `angle A B` rows. Manual
   entry needs no board, so the fit-and-generate path still works from numbers on
   paper — type the dark reading into the box beside the DARK button and set
   "noise mV" to the per-sample scatter you expect.
4. **FIT + GENERATE calib.h** → **Copy**.
5. Paste over the block in `firmware/comp_sensor/calib.h`, re-upload.
6. The board reboots into RUN mode.

## Verified

`tests/sim_head.py` runs the whole pipeline against a simulated head with the
cells fixed at ±20°, a 1.5 mm blade, stray light, a deliberately wrong γ, 18%
cell mismatch and 1.5 mV of ADC noise. It finds the 20–160° ratio zone by
itself, builds both amplitude tables, and returns blind angles within 0.38° in
the ratio zone and 0.04° in the ends — 0.5° after a ±60% change in LED
brightness, against 12–18° with the brightness reference disabled.
`tests/check_firmware.py` compiles the firmware's own maths, including the
branch logic, as C and runs it against the same head. `tests/check_compile.py`
builds the whole sketch with the IDE's prototype hoisting reproduced, against
Arduino stubs, fails on any warning, and checks `platformio.ini` still points at
the sketch folder. It does not exercise the ESP32 toolchain — the PlatformIO
registry is outside this session's network allowlist, so a real device build is
still the one thing only you can prove.

**A note on `struct Meas`.** It lives in `config.h`, not in the .ino, and must
stay there. The IDE hoists a prototype for every sketch function above the body,
so `static Meas measure()` sees `Meas` before its definition and fails with
`error: 'Meas' does not name a type`. Any new type used in a function signature
goes in a header for the same reason.
