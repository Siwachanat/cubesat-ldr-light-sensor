#!/usr/bin/env python3
"""Move a sweep or a calibration onto a differently-zeroed protractor.

    python3 rezero.py -90 data/sweep_short.csv firmware/comp_sensor/calib.h

Only the ZERO of the protractor changes, so this is a pure offset on angle
values and nothing else. Voltages, L, the noise columns, the lookup grid in L,
CAL_SUM, the darkness thresholds - none of them know or care where the
protractor's zero is. That is why this is a safe mechanical edit and not a
refit: the physics is unchanged, only the labels on the arc moved.

In a calib.h that means exactly four things:
    CAL_THETA[]   the angle each ratio-table row maps to
    CAL_AL_TH[]   the angle each low-end level-table row maps to
    CAL_AH_TH[]   the same for the high end
    CAL_ANG_MIN / CAL_ANG_MAX   the ends of the OLED position bar

CAL_L0, CAL_DL, CAL_LNK, CAL_SIGMA[], CAL_SUM[], CAL_E_EDGE_A/B and the
amplitude tables' x0/dx are all in units of ln E or L. They are untouched.

Files are rewritten in place with a .bak alongside.
"""
import os
import re
import shutil
import sys

ARRAYS = ("CAL_THETA", "CAL_AL_TH", "CAL_AH_TH")
SCALARS = ("CAL_ANG_MIN", "CAL_ANG_MAX")


def shift_csv(path, d):
    with open(path) as fh:
        lines = fh.read().splitlines()
    out, n = [], 0
    for ln in lines:
        if not ln.strip() or ln.startswith("#") or ln.startswith("angle,"):
            out.append(ln)
            continue
        f = ln.split(",")
        try:
            f[0] = "%g" % (float(f[0]) + d)
        except ValueError:
            out.append(ln)
            continue
        out.append(",".join(f))
        n += 1
    with open(path, "w") as fh:
        fh.write("\n".join(out) + "\n")
    return "%d angles" % n


def shift_header(path, d):
    s = open(path).read()
    n = [0]

    def one(m):
        n[0] += 1
        return "%9.4ff" % (float(m.group(1)) + d)

    for name in ARRAYS:
        m = re.search(r"(%s\s*\[[^\]]*\]\s*=\s*\{)(.*?)(\};)" % name, s, re.S)
        if not m:
            continue
        body = re.sub(r"(-?[\d.]+(?:[eE][-+]?\d+)?)f", one, m.group(2))
        s = s[:m.start(2)] + body + s[m.end(2):]

    for name in SCALARS:
        def sc(m, _n=name):
            n[0] += 1
            return "#define %s   %.2ff" % (_n, float(m.group(1)) + d)
        s = re.sub(r"#define\s+%s\s+(-?[\d.]+(?:[eE][-+]?\d+)?)f" % name, sc, s)

    s = s.replace("#pragma once",
                  "#pragma once\n/* angles re-zeroed by %+g deg by rezero.py */" % d, 1)
    open(path, "w").write(s)
    return "%d angle values" % n[0]


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 2
    try:
        d = float(argv[1])
    except ValueError:
        print("first argument must be the offset in degrees, e.g. -90")
        return 2
    for path in argv[2:]:
        if not os.path.exists(path):
            print("  !! %s does not exist" % path)
            continue
        shutil.copy2(path, path + ".bak")
        if path.endswith(".csv"):
            what = shift_csv(path, d)
        elif path.endswith((".h", ".hpp")):
            what = shift_header(path, d)
        else:
            print("  !! %s: only .csv and .h are handled" % path)
            continue
        print("  %-44s %+g deg applied to %s  (.bak kept)" % (path, d, what))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
