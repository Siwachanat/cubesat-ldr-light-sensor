#pragma once
#include <cstdint>
struct TwoWire {
  void end() {}
  void begin(uint8_t, uint8_t, uint32_t) {}
  void beginTransmission(uint8_t) {}
  int endTransmission() { return 0; }
} extern Wire;
