/* Minimal stub of the ESP32 core's Preferences (NVS) class.
 * Declares only the members every core version has, so a sketch that
 * compiles here cannot use an API the real board lacks. */
#pragma once
#include <Arduino.h>

class Preferences {
public:
  bool   begin(const char *name, bool readOnly = false) { (void)name; (void)readOnly; return true; }
  void   end() {}
  bool   isKey(const char *key) { (void)key; return false; }
  bool   remove(const char *key) { (void)key; return true; }
  size_t putFloat(const char *key, float value) { (void)key; (void)value; return 4; }
  float  getFloat(const char *key, float defaultValue = 0) { (void)key; return defaultValue; }
  size_t putString(const char *key, const char *value) { (void)key; (void)value; return 0; }
  String getString(const char *key, const char *defaultValue = "") { (void)key; return String(defaultValue); }
};
