#pragma once
#include <Wire.h>
#include <cstdint>
#define SSD1306_WHITE 1
#define SSD1306_SWITCHCAPVCC 2
class Adafruit_SSD1306 {
public:
  Adafruit_SSD1306(int, int, TwoWire *, int) {}
  bool begin(int, uint8_t) { return true; }
  void clearDisplay() {}
  void setTextColor(int) {}
  void setTextSize(int) {}
  void setCursor(int, int) {}
  void print(const char *) {}
  template <class... A> void printf(const char *, A...) {}
  void drawRect(int, int, int, int, int) {}
  void fillRect(int, int, int, int, int) {}
  void drawFastVLine(int, int, int, int) {}
  void display() {}
};
