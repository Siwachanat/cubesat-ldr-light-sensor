#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <string>
#define SOC_BT_SUPPORTED 1
#define INPUT_PULLUP 2
#define LOW 0
#define HIGH 1
/* Only the spellings that exist in EVERY ESP32 core are declared here, on
   purpose: anything narrower must fail this check rather than pass it and
   then fail on the bench. */
typedef enum { ADC_0db = 0, ADC_2_5db = 1, ADC_6db = 2, ADC_11db = 3,
               ADC_ATTENDB_MAX = 4 } adc_attenuation_t;
class String {
  std::string s;
public:
  String() {}
  String(const char *p) : s(p ? p : "") {}
  String(const String &o) : s(o.s) {}
  void trim() { while(!s.empty() && isspace((unsigned char)s.front())) s.erase(s.begin());
                while(!s.empty() && isspace((unsigned char)s.back())) s.pop_back(); }
  void toUpperCase() { for (auto &c : s) c = toupper((unsigned char)c); }
  unsigned length() const { return (unsigned)s.size(); }
  bool startsWith(const char *p) const { return s.rfind(p, 0) == 0; }
  int indexOf(const char *p) const { auto i = s.find(p); return i == std::string::npos ? -1 : (int)i; }
  String substring(unsigned a) const { return String(s.substr(a < s.size() ? a : s.size()).c_str()); }
  long toInt() const { return atol(s.c_str()); }
  float toFloat() const { return (float)atof(s.c_str()); }
  const char *c_str() const { return s.c_str(); }
  bool operator==(const char *p) const { return s == p; }
  bool operator==(const String &r) const { return s == r.s; }
  String &operator+=(char c) { s.push_back(c); return *this; }
  String &operator=(const char *p) { s = p ? p : ""; return *this; }
};
struct SerialClass {
  void begin(long) {}
  template <class... A> void printf(const char *, A...) {}
  void println(const char *) {}
  int available() { return 0; }
  int read() { return -1; }
} extern Serial;
inline void delay(unsigned long) {}
inline unsigned long millis() { return 0; }
inline void pinMode(int, int) {}
inline int digitalRead(int) { return 1; }
inline uint32_t analogReadMilliVolts(int) { return 1000; }
inline void analogReadResolution(int) {}
inline void analogSetPinAttenuation(int, adc_attenuation_t) {}
inline void btStop() {}
#define constrain(a,l,h) ((a)<(l)?(l):((a)>(h)?(h):(a)))
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
