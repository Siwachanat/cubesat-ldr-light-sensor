#pragma once
#define WIFI_OFF 0
struct WiFiClass { void mode(int) {} void disconnect(bool) {} } extern WiFi;
