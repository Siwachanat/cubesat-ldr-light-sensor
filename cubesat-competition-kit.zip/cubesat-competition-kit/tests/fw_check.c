/* Transliteration of the firmware maths, checked against comp_gui.py.
 * Reads "vA vB" pairs on stdin, prints the angle the ESP32 would show. */
#include <stdio.h>
#include <math.h>

#include "calib_sim.h"

#define CAL_VREF_MV 3300.0f
#define CAL_RF_A    8200.0f
#define CAL_RF_B    8200.0f
#define CAL_GAMMA_A 0.70f
#define CAL_GAMMA_B 0.70f
#define CAL_GD_A    SIM_GDA
#define CAL_GD_B    SIM_GDB

static float conductance(float v_mV, float rf, float vref) {
  if (v_mV < 0.001f) v_mV = 0.001f;
  if (v_mV > vref - 0.001f) v_mV = vref - 0.001f;
  float r = rf * (vref / v_mV - 1.0f);
  if (r < 1e-6f) r = 1e-6f;
  return 1.0f / r;
}

static float irradiance(float v_mV, float rf, float vref, float gd, float gamma) {
  float g = conductance(v_mV, rf, vref) - gd;
  if (g < 1e-12f) g = 1e-12f;
  return powf(g, 1.0f / gamma);
}

static float ampAngle(float x, float x0, float dx, const float *tab, int n,
                      int *clipped) {
  float u = (x - x0) / dx;
  *clipped = 0;
  if (u < 0.0f)         { u = 0.0f;         *clipped = 1; }
  if (u > (float)(n-1)) { u = (float)(n-1); *clipped = 1; }
  int i = (int)floorf(u);
  if (i > n - 2) i = n - 2;
  if (i < 0) i = 0;
  float f = u - (float)i;
  return tab[i] + f * (tab[i + 1] - tab[i]);
}

static float lutSum(float L) {
  float x = (L - CAL_L0) / CAL_DL;
  if (x < 0.0f) x = 0.0f;
  if (x > (float)(CAL_N-1)) x = (float)(CAL_N-1);
  int i = (int)floorf(x);
  if (i > CAL_N - 2) i = CAL_N - 2;
  if (i < 0) i = 0;
  float f = x - (float)i;
  return CAL_SUM[i] + f * (CAL_SUM[i + 1] - CAL_SUM[i]);
}

static float ampRef = 0.0f;
static int   ampRefValid = 0;
#define AMP_ALPHA 0.02f

static float lutAngle(float L, float *sigma_out, int *status) {
  (void)sigma_out;
  if (CAL_N < 2) { *status = 4; return NAN; }
  float x = (L - CAL_L0) / CAL_DL;
  *status = 0;
  if (x < 0.0f)             { x = 0.0f;             *status = 1; }
  if (x > (float)(CAL_N-1)) { x = (float)(CAL_N-1); *status = 2; }
  int i = (int)floorf(x);
  if (i > CAL_N - 2) i = CAL_N - 2;
  if (i < 0) i = 0;
  float f = x - (float)i;
  return CAL_THETA[i] + f * (CAL_THETA[i + 1] - CAL_THETA[i]);
}

int main(void) {
  double vA, vB;
  while (scanf("%lf %lf", &vA, &vB) == 2) {
    float eA = irradiance((float)vA, CAL_RF_A, CAL_VREF_MV, CAL_GD_A, CAL_GAMMA_A);
    float eB = irradiance((float)vB, CAL_RF_B, CAL_VREF_MV, CAL_GD_B, CAL_GAMMA_B);
    float L = logf(eA) - logf(eB) - CAL_LNK;
    float s; int st;
    float a = lutAngle(L, &s, &st);

    float amp1 = ampRefValid ? expf(ampRef) : 1.0f;
    int bothLit = (eA > CAL_E_EDGE_A * amp1) && (eB > CAL_E_EDGE_B * amp1);
    int ratioOK = (st == 0) && bothLit;
    if (ratioOK) {
      float err = logf(eA + eB) - lutSum(L);
      if (!ampRefValid) { ampRef = err; ampRefValid = 1; }
      else              { ampRef += AMP_ALPHA * (err - ampRef); }
    } else {
      int lit = (eA >= eB) ? 0 : 1;
      int n = 0, clipped = 0; float x0 = 0, dx = 1; const float *tab = 0;
      if (CAL_AL_N >= 2 && CAL_AL_CH == lit) {
        n = CAL_AL_N; x0 = CAL_AL_X0; dx = CAL_AL_DX; tab = CAL_AL_TH;
      } else if (CAL_AH_N >= 2 && CAL_AH_CH == lit) {
        n = CAL_AH_N; x0 = CAL_AH_X0; dx = CAL_AH_DX; tab = CAL_AH_TH;
      }
      if (n >= 2) {
        a = ampAngle(logf(lit ? eB : eA) - ampRef, x0, dx, tab, n, &clipped);
        st = clipped ? 1 : 5;
      }
    }
    printf("%.4f %d\n", a, st);
  }
  return 0;
}
