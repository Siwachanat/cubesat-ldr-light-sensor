#!/usr/bin/env python3
"""Compile the firmware maths as C and check it against the Python pipeline."""
import os
import subprocess
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
import comp_gui as C
from sim_head import volts, dark_volts, RF, VREF


def main():
    hdr = os.path.join(HERE, "calib_sim.h")
    if not os.path.exists(hdr):
        print("run sim_head.py first")
        return 1
    exe = os.path.join(HERE, "fw_check")
    subprocess.check_call(["gcc", "-O2", "-I", HERE,
                           os.path.join(HERE, "fw_check.c"), "-o", exe, "-lm"])

    txt = open(hdr).read()

    def grab(name):
        for ln in txt.splitlines():
            if ln.startswith("#define " + name):
                return float(ln.split()[2].rstrip("f"))
        raise KeyError(name)

    rng = np.random.default_rng(11)
    truth = np.arange(2.0, 178.1, 2.0)
    vA, vB = volts(truth, 1.0, rng)

    inp = "\n".join("%.6f %.6f" % (a, b) for a, b in zip(vA, vB))
    out = subprocess.run([exe], input=inp, capture_output=True, text=True).stdout
    c_ang = np.array([float(ln.split()[0]) for ln in out.strip().splitlines()])

    err = c_ang - truth
    print("C firmware vs truth   max error  %.3f deg   rms %.3f deg"
          % (np.abs(err).max(), np.sqrt(np.mean(err ** 2))))
    mid = (truth >= 25) & (truth <= 155)
    end = ~mid
    print("                      ratio zone 25..155  worst %.3f deg"
          % np.abs(err[mid]).max())
    print("                      amplitude ends      worst %.3f deg"
          % np.abs(err[end]).max())
    ok = np.abs(err[mid]).max() < 1.0 and np.abs(err[end]).max() < 1.5
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
