#!/usr/bin/env python3
"""Drive the GUI headless: fake telemetry -> capture -> fit -> calib.h."""
import os
import sys

os.environ["QT_QPA_PLATFORM"] = "offscreen"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
from PyQt5 import QtWidgets
import comp_gui as C
from sim_head import volts, dark_volts

rng = np.random.default_rng(5)


def feed(win, angle, n):
    """Push n telemetry lines for one angle, as the ESP32 would."""
    vA, vB = volts(np.full(n, float(angle)), 1.0, rng)
    for a, b in zip(vA, vB):
        win.on_line("T,1234,%.1f,%.1f,+0.0,+0.0,0.0,0.0,ok" % (a, b))


def main():
    app = QtWidgets.QApplication([])
    win = C.Main()
    win.show()

    class FakeReader(object):
        def send(self, _):
            pass

        def stop(self):
            pass

    win.reader = FakeReader()

    # 1 - dark
    win.spin_n.setValue(20)
    win.capture_dark()
    vdA, vdB = dark_volts()
    for _ in range(20):
        win.on_line("T,0,%.1f,%.1f,0,0,0,0,ok" % (vdA, vdB))
    assert win.capture_buf is None, "dark capture did not finish"
    print("dark:", win.lbl_dark.text())
    assert win.gd[0] > 0 and win.gd[1] > 0

    # 2 - a 5 degree sweep
    win.spin_n.setValue(24)
    win.chk_auto.setChecked(False)
    for a in np.arange(0.0, 180.1, 5.0):
        win.spin_angle.setValue(float(a))
        win.capture_point()
        feed(win, a, 24)
    print("captured rows:", len(win.rows))
    assert len(win.rows) == 37, len(win.rows)

    # 3 - a second labelled run, to prove grouping and averaging work
    win.edit_note.setText("run2")
    for a in [30.0, 90.0, 150.0]:
        win.spin_angle.setValue(a)
        win.capture_point()
        feed(win, a, 24)
    assert len(win.rows) == 40

    # 4 - fit
    win.do_fit()
    out = win.txt_out.toPlainText()
    print("\n".join(out.splitlines()[:11]))
    assert "CAL_THETA" in out and "CAL_SIGMA" in out
    n = int([l for l in out.splitlines() if l.startswith("#define CAL_N")][0].split()[-1])
    assert n == win.spin_rows.value(), n

    # 5 - CSV round trip
    p = os.path.join(HERE, "_smoke.csv")
    win.save_csv = lambda: None            # avoid the dialog; write by hand
    import csv as _csv
    with open(p, "w", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(C.Main.FIELDS)
        for r in win.rows:
            w.writerow([r[k] for k in C.Main.FIELDS])
    rows = win._read_csv(p)
    assert len(rows) == len(win.rows)
    os.remove(p)

    # 6 - plots have content
    for name, plot in [("response", win.p_resp), ("curve", win.p_curve),
                       ("resolution", win.p_res), ("residuals", win.p_resid)]:
        assert len(plot.listDataItems()) > 0, name
    print("\nplots ok, csv ok")
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
