#!/usr/bin/env python3
"""Simulated competition head: two LDRs FIXED at +/-20 deg outward, one
designable opaque centre blade.  Exercises the GUI maths end to end,
including the amplitude fallback in the ends the ratio cannot reach."""
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import comp_gui as C

# ---- the rig ----------------------------------------------------------
BETA = 20.0            # splay per side, fixed by the organisers
W_CELL = 4.3           # LXD5528A window width, mm
BLADE_H = 1.5          # what we get to choose: blade proud of the cell faces
BLADE_G = 0.0          # gap cell-to-blade; tabs close it

VREF = 3300.0
RF = 8200.0
GAMMA_TRUE = 0.72          # firmware will assume 0.70 - deliberately wrong
GDARK_A = 1.0e-6
GDARK_B = 1.15e-6
KMIS = 1.18                # cell-to-cell sensitivity mismatch
CGAIN = 4.6e-4
ADC_NOISE_MV = 1.5
STRAY = 0.012              # residual bounce reaching a geometrically dark cell


def cells(TH):
    """Protractor angle -> irradiance on each cell, before electronics."""
    TH = np.atleast_1d(np.asarray(TH, float))
    dA = np.maximum(np.cos(np.radians(TH - (90.0 - BETA))), 0.0)
    dB = np.maximum(np.cos(np.radians(TH - (90.0 + BETA))), 0.0)
    th = np.radians(TH - 90.0)                       # from boresight
    f = np.clip((BLADE_G + W_CELL - BLADE_H * np.tan(np.abs(th))) / W_CELL, 0, 1)
    eA = dA * np.where(th > 0, f, 1.0) + STRAY       # blade shadows the far cell
    eB = dB * np.where(th < 0, f, 1.0) + STRAY
    return eA, eB


def volts(TH, brightness=1.0, rng=None):
    eA, eB = cells(TH)
    eA, eB = eA * brightness, eB * brightness
    gA = CGAIN * np.power(np.maximum(eA, 1e-9), GAMMA_TRUE) + GDARK_A
    gB = KMIS * CGAIN * np.power(np.maximum(eB, 1e-9), GAMMA_TRUE) + GDARK_B
    vA = VREF * gA * RF / (1.0 + gA * RF)
    vB = VREF * gB * RF / (1.0 + gB * RF)
    if rng is not None:
        vA = vA + rng.normal(0, ADC_NOISE_MV, np.shape(vA))
        vB = vB + rng.normal(0, ADC_NOISE_MV, np.shape(vB))
    return vA, vB


def dark_volts():
    vA = VREF * GDARK_A * RF / (1.0 + GDARK_A * RF)
    vB = VREF * GDARK_B * RF / (1.0 + GDARK_B * RF)
    return vA, vB


def main():
    rng = np.random.default_rng(7)
    ok = True

    vdA, vdB = dark_volts()
    gdA = float(C.conductance(vdA, RF, VREF))
    gdB = float(C.conductance(vdB, RF, VREF))
    print("head: cells fixed at +/-%.0f deg, blade h = %.1f mm, g = %.1f mm"
          % (BETA, BLADE_H, BLADE_G))
    print("dark node voltage   A %.1f mV   B %.1f mV" % (vdA, vdB))

    def sample(th, brightness=1.0, n=40):
        vA, vB = volts(np.full(n, float(th)), brightness, rng)
        eA = C.irradiance(vA, RF, VREF, gdA, 0.70)
        eB = C.irradiance(vB, RF, VREF, gdB, 0.70)
        return vA, vB, eA, eB

    angles = np.arange(0.0, 180.1, 5.0)
    L, sdL, EA, EB = [], [], [], []
    for a in angles:
        vA, vB, eA, eB = sample(a)
        l = C.log_ratio(eA, eB)
        L.append(np.mean(l)); sdL.append(np.std(l))
        EA.append(np.mean(eA)); EB.append(np.mean(eB))
    L = np.array(L); EA = np.array(EA); EB = np.array(EB)

    edge_a, floor_a, litA = C.cell_dark_threshold(EA)
    edge_b, floor_b, litB = C.cell_dark_threshold(EB)
    span, (a0, a1) = C.longest_monotone_span(angles, L, litA & litB)
    print("ratio zone (both lit)     %.0f .. %.0f deg   (%.0f deg wide)"
          % (a0, a1, span))
    # Narrower than the geometric 20..160 on purpose: a cell sitting a few
    # times above its stray floor carries almost no ratio, and the level
    # branch reads those angles better. Demand a wide, centred zone, and let
    # the seam check below prove the handover is smooth.
    if not (a1 - a0 >= 100 and abs((a0 + a1) / 2 - 90) <= 8):
        print("  !! expected a wide zone centred on 90 for a +/-20 deg pair")
        ok = False

    keep = (angles >= a0) & (angles <= a1)
    c0 = C.MonotoneCurve(angles[keep], L[keep])
    lnk = float(c0.L_of(90.0))
    curve = C.MonotoneCurve(angles[keep], L[keep] - lnk)
    L0, dL, table, _ = C.build_lut(curve, 64)
    sigma_L = float(np.median(np.array(sdL)[keep]))
    print("ratio LUT   n=%d  L %.3f..%.3f  theta %.1f..%.1f  sigma_L %.4f"
          % (len(table), L0, L0 + dL * 63, min(table), max(table), sigma_L))

    # amplitude branch, exactly as the GUI builds it
    lnS = np.log(EA + EB)
    sum_rows = np.interp(table, angles, lnS)
    amp = {}
    e_edge = float(np.sqrt(edge_a * edge_b))
    print("cell A floor E %.4g  dark below %.4g" % (floor_a, edge_a))
    print("cell B floor E %.4g  dark below %.4g" % (floor_b, edge_b))
    ov = 1.6 * float(np.median(np.diff(angles)))
    for mask, key in ((angles <= a0 + ov, "lo"), (angles >= a1 - ov, "hi")):
        ta = angles[mask]
        ch = 0 if np.mean(EA[mask]) >= np.mean(EB[mask]) else 1
        x = np.log((EA if ch == 0 else EB)[mask])
        sp, (b0, b1) = C.longest_monotone_span(ta, x)
        k = (ta >= b0) & (ta <= b1)
        ac = C.MonotoneCurve(ta[k], x[k])
        x0, dx, atab, _ = C.build_lut(ac, 48)
        amp[key] = dict(ch=ch, x0=x0, dx=dx, tab=atab)
        print("amp branch  %s: cell %s over %.0f..%.0f deg, n=%d"
              % (key, "AB"[ch], ta[k].min(), ta[k].max(), len(atab)))
    if len(amp) != 2:
        print("  !! both ends should have produced a fallback")
        ok = False

    def estimate(th, brightness=1.0, ampref=0.0):
        vA, vB, eA, eB = sample(th, brightness)
        l = float(np.mean(C.log_ratio(eA, eB))) - lnk
        mA, mB = float(np.mean(eA)), float(np.mean(eB))
        g = np.exp(ampref)
        inrange = (L0 - 1e-9) <= l <= (L0 + dL * (len(table) - 1) + 1e-9)
        if mA > edge_a * g and mB > edge_b * g and inrange:
            return float(C.lut_lookup(L0, dL, table, l)), "ok"
        lit = 0 if mA >= mB else 1
        key = "lo" if amp["lo"]["ch"] == lit else "hi"
        a = amp[key]
        e = mA if lit == 0 else mB
        return (float(C.lut_lookup(a["x0"], a["dx"], a["tab"],
                                   np.log(e) - ampref)), "amp")

    print("\nblind angles, fresh noise")
    print("  true   reported   error   branch")
    worst_ratio = worst_amp = 0.0
    for a in [3.0, 8.0, 14.0, 23.0, 37.0, 63.0, 88.0, 92.5, 118.0,
              141.0, 158.0, 168.0, 176.0]:
        est, br = estimate(a)
        err = est - a
        print("  %5.1f  %8.2f  %+7.3f   %s" % (a, est, err, br))
        if br == "ok":
            worst_ratio = max(worst_ratio, abs(err))
        else:
            worst_amp = max(worst_amp, abs(err))
    print("worst in the ratio zone   %.3f deg" % worst_ratio)
    print("worst in the amp ends     %.3f deg" % worst_amp)
    if worst_ratio > 1.0 or worst_amp > 1.0:
        ok = False

    print("\nbrightness immunity")
    for b in (0.6, 1.6):
        # The firmware always has its brightness reference: it scales the
        # darkness thresholds as well as feeding the level branch, so give it
        # to both probes. Without it the ZONE EDGES flip branch under a big
        # brightness change, which is a selector failure, not an estimator one.
        ref = np.log(b)
        # Probe inside the zone, not on its edge: at the edge the branch is
        # SUPPOSED to hand over, and what matters there is that the two
        # estimators agree - checked separately below.
        e_ratio = max(abs(estimate(a, b, ampref=ref)[0] - a)
                      for a in [a0 + 2, 60., 90., 120., a1 - 2])
        e_amp = max(abs(estimate(a, b, ampref=ref)[0] - a) for a in [5., 12., 168., 175.])
        e_amp_noref = max(abs(estimate(a, b)[0] - a) for a in [5., 12., 168., 175.])
        print("  LED at %3.0f%%   ratio zone %.3f deg | amp ends %.3f deg with the "
              "brightness reference, %.2f deg without"
              % (b * 100, e_ratio, e_amp, e_amp_noref))
        if e_ratio > 1.0 or e_amp > 1.5:
            ok = False

    # Handover continuity. A reading walked slowly across a zone edge must not
    # jump: the ratio table and the level table overlap there on purpose, and
    # a step at the seam is the one failure a user sees as the sensor "lying".
    print("\nhandover across the zone edges")
    worst_seam = 0.0
    for edge in (a0, a1):
        for off in (-1.5, -0.5, 0.5, 1.5):
            a = edge + off
            est, br = estimate(a)
            worst_seam = max(worst_seam, abs(est - a))
        print("  %.0f deg  worst %.3f deg over +/-1.5 deg" % (edge, worst_seam))
    if worst_seam > 1.0:
        print("  !! the seam steps - the level tables do not overlap the zone")
        ok = False

    out = os.path.join(os.path.dirname(__file__), "calib_sim.h")
    with open(out, "w") as fh:
        fh.write("#define CAL_LNK %.6ff\n#define CAL_L0 %.6ff\n"
                 "#define CAL_DL %.6ff\n#define CAL_N %d\n"
                 % (lnk, L0, dL, len(table)))
        fh.write("static const float CAL_THETA[CAL_N] = {\n")
        for i in range(0, len(table), 6):
            fh.write("  " + ", ".join("%.4ff" % v for v in table[i:i + 6]) + ",\n")
        fh.write("};\n")
        fh.write("static const float CAL_SUM[CAL_N] = {\n")
        for i in range(0, len(sum_rows), 6):
            fh.write("  " + ", ".join("%.5ff" % v for v in sum_rows[i:i + 6]) + ",\n")
        fh.write("};\n")
        for key, tag in (("lo", "AL"), ("hi", "AH")):
            a = amp[key]
            fh.write("#define CAL_%s_N %d\n#define CAL_%s_CH %d\n"
                     "#define CAL_%s_X0 %.6ff\n#define CAL_%s_DX %.6ff\n"
                     % (tag, len(a["tab"]), tag, a["ch"], tag, a["x0"], tag, a["dx"]))
            fh.write("static const float CAL_%s_TH[CAL_%s_N] = {\n" % (tag, tag))
            for i in range(0, len(a["tab"]), 6):
                fh.write("  " + ", ".join("%.4ff" % v for v in a["tab"][i:i + 6]) + ",\n")
            fh.write("};\n")
        fh.write("#define CAL_E_EDGE %.9gf\n" % e_edge)
        fh.write("#define CAL_E_EDGE_A %.9gf\n" % edge_a)
        fh.write("#define CAL_E_EDGE_B %.9gf\n" % edge_b)
        fh.write("#define SIM_GDA %.9gf\n#define SIM_GDB %.9gf\n" % (gdA, gdB))
    print("\nwrote %s" % out)
    print("\n%s" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
