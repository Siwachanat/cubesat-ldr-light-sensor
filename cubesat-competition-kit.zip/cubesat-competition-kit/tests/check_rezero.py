#!/usr/bin/env python3
"""The pipeline must not care where the protractor's zero is.

Fit a sweep, re-zero every angle by -90, fit again, and check that the ONLY
things that moved are the angle values - by exactly -90, to the last digit.
Everything else (the grid in L, the boresight trim, the brightness table, the
darkness thresholds, the level tables' x0/dx) lives in units of ln E and must
come out bit-identical.

If this fails, something in the fit has an absolute angle baked into it, and
moving to the competition's -90..+90 scale would silently change the answer.
"""
import os
import re
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from PyQt5 import QtWidgets                                    # noqa: E402
import comp_gui as C                                           # noqa: E402

SHIFT = -90.0
ANGLE_KEYS = ("CAL_ANG_MIN", "CAL_ANG_MAX")
ANGLE_ARRAYS = ("CAL_THETA", "CAL_AL_TH", "CAL_AH_TH")


def defines(block):
    return dict(re.findall(r"#define\s+(CAL_\w+)\s+(\S+)", block))


def arrays(block):
    out = {}
    for m in re.finditer(r"(CAL_\w+)\s*\[[^\]]*\]\s*=\s*\{(.*?)\};", block, re.S):
        out[m.group(1)] = [float(x) for x in
                           re.findall(r"-?[\d.]+(?:[eE][-+]?\d+)?", m.group(2))]
    return out


def fit(win, csv, bore):
    win.rows = win._read_csv(csv)
    win.edit_note.setText("rz")
    win.spin_bore.setValue(bore)
    win.spin_rows.setValue(64)
    win.do_fit()
    txt = win.txt_out.toPlainText()
    i = txt.index("/* ---------- calib.h")
    return txt[i:]


def main():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    csv = os.path.join(HERE, "..", "data", "sweep_short.csv")
    if not os.path.exists(csv):
        print("data/sweep_short.csv missing - skipping")
        return 0

    win = C.Main()
    a = fit(win, csv, 95.0)

    # Shift the file with the shipped rezero.py, so this also proves that
    # tool. Copying the file keeps the "#" header, and with it the dark
    # reference - drop that and every E changes and nothing below matches.
    import shutil
    sys.path.insert(0, os.path.join(HERE, ".."))
    import rezero
    shifted = os.path.join(HERE, "_rezero.csv")
    shutil.copy2(csv, shifted)
    rezero.shift_csv(shifted, SHIFT)
    b = fit(win, shifted, 95.0 + SHIFT)
    os.remove(shifted)
    if os.path.exists(shifted + ".bak"):
        os.remove(shifted + ".bak")

    da, db = defines(a), defines(b)
    aa, ab = arrays(a), arrays(b)
    ok = True

    for k in sorted(set(da) | set(db)):
        va, vb = da.get(k), db.get(k)
        if k in ANGLE_KEYS:
            fa, fb = float(va.rstrip("f")), float(vb.rstrip("f"))
            if abs((fb - fa) - SHIFT) > 5e-3:
                print("  !! %s moved by %+.4f, expected %+.1f" % (k, fb - fa, SHIFT))
                ok = False
            else:
                print("  %-14s %10s -> %-10s  shifted" % (k, va, vb))
        elif va != vb:
            print("  !! %s changed: %s -> %s  (should be identical)" % (k, va, vb))
            ok = False

    for k in sorted(set(aa) | set(ab)):
        xa, xb = aa.get(k, []), ab.get(k, [])
        if len(xa) != len(xb):
            print("  !! %s length %d -> %d" % (k, len(xa), len(xb)))
            ok = False
            continue
        d = [y - x for x, y in zip(xa, xb)]
        want = SHIFT if k in ANGLE_ARRAYS else 0.0
        worst = max(abs(v - want) for v in d) if d else 0.0
        if worst > 5e-3:
            print("  !! %s: worst deviation %.4f from the expected %+.1f"
                  % (k, worst, want))
            ok = False
        else:
            print("  %-14s n=%-4d %s (worst %.5f)"
                  % (k, len(xa), "shifted" if want else "unchanged", worst))

    print("\n" + ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
