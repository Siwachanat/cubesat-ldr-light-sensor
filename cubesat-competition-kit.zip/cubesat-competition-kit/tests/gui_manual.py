#!/usr/bin/env python3
"""Headless test of the GUI's manual-entry mode: typed dark, typed points,
pasted rows, ADC-counts units, then the full fit and calib.h generation."""
import os
import sys

os.environ["QT_QPA_PLATFORM"] = "offscreen"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
from PyQt5 import QtWidgets
import comp_gui as C
from sim_head import volts, dark_volts, VREF


def main():
    app = QtWidgets.QApplication([])
    win = C.Main()
    win.show()
    assert win.reader is None, "manual mode must not need a serial port"

    # --- 1. dark, typed in mV
    vdA, vdB = dark_volts()
    win.tabs_entry.setCurrentIndex(1)
    win.edit_dark.setText("%.1f, %.1f" % (vdA, vdB))
    win.set_dark_manual()
    print("dark:", win.lbl_dark.text())
    assert win.gd[0] > 0 and win.gd[1] > 0

    # --- 2. one point typed by hand, in mV
    win.chk_auto.setChecked(False)
    vA, vB = volts(np.array([90.0]))
    win.spin_angle.setValue(90.0)
    win.edit_a.setText("%.0f" % vA[0])
    win.edit_b.setText("%.0f" % vB[0])
    win.add_manual()
    assert len(win.rows) == 1, win.rows
    assert win.edit_a.text() == "" and win.edit_b.text() == "", "fields should clear"
    r = win.rows[0]
    assert r["sdL"] > 0, "typed points must still carry a synthesised sd"
    print("one typed point: angle %.0f  L %+.4f  sdL %.4f" % (r["angle"], r["L"], r["sdL"]))

    # --- 3. the rest of the sweep as a pasted block, mV
    lines = []
    for a in np.arange(0.0, 180.1, 5.0):
        if a == 90.0:
            continue
        x, y = volts(np.array([a]))
        lines.append("%g %.0f %.0f" % (a, x[0], y[0]))
    win.txt_paste.setPlainText("\n".join(lines))
    win.add_pasted()
    print("after paste:", len(win.rows), "rows")
    assert len(win.rows) == 37, len(win.rows)

    # --- 4. a bad paste must be reported, not crash
    win.txt_paste.setPlainText("oops\n200 1 2\n45\n# comment\n47 2100 1500")
    n_before = len(win.rows)
    win.add_pasted()
    print("bad paste ->", win.statusBar().currentMessage())
    assert len(win.rows) == n_before + 1, "only the one good row should land"
    win.rows = [r for r in win.rows if abs(r["angle"] - 47.0) > 1e-9]

    # --- 5. ADC counts: the same point must land at the same voltage
    win.cmb_unit.setCurrentIndex(1)
    assert win.spin_fs.isVisible() or True     # offscreen: just check it converts
    counts_a = vA[0] / VREF * 4095.0
    counts_b = vB[0] / VREF * 4095.0
    win.edit_note.setText("counts")
    win.spin_angle.setValue(90.0)
    win.edit_a.setText("%.0f" % counts_a)
    win.edit_b.setText("%.0f" % counts_b)
    win.add_manual()
    got = [r for r in win.rows if r["note"] == "counts"][0]
    print("counts point: %.1f mV vs %.1f mV typed in mV" % (got["vA"], vA[0]))
    assert abs(got["vA"] - vA[0]) < 1.0, (got["vA"], vA[0])
    win.rows = [r for r in win.rows if r["note"] != "counts"]
    win.cmb_unit.setCurrentIndex(0)

    # --- 6. out-of-range typed value is refused without a dialog crash
    win.edit_a.setText("9999")
    win.edit_b.setText("1000")
    n_before = len(win.rows)
    QtWidgets.QMessageBox.warning = staticmethod(lambda *a, **k: None)
    win.add_manual()
    assert len(win.rows) == n_before, "a value above VREF must be refused"

    # --- 7. the full fit runs on entirely typed data
    win.do_fit()
    out = win.txt_out.toPlainText()
    head = [l for l in out.splitlines() if l and not l.startswith("/*")][:12]
    print("\n".join(head))
    assert "CAL_THETA" in out and "CAL_AL_N" in out and "CAL_E_EDGE" in out
    zone = [l for l in out.splitlines() if "both cells lit" in l][0]
    lo, hi = [float(x) for x in zone.split("lit")[1].split("deg")[0].split("to")]
    # The zone is where BOTH cells are clear of their own stray-light floors,
    # which is narrower than the geometric 20..160 - points where a cell is
    # only a few times its floor carry almost no ratio, and the level branch
    # serves them better. What must hold is that the zone is wide and centred.
    assert (hi - lo) >= 100.0, (lo, hi)
    assert abs((lo + hi) / 2 - 90.0) <= 8.0, (lo, hi)
    assert any("cell A" in l for l in out.splitlines()), "low-end fallback missing"
    assert any("cell B" in l for l in out.splitlines()), "high-end fallback missing"

    print("\nPASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
