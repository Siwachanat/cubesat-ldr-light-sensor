#!/usr/bin/env python3
"""Compile the sketch the way the Arduino IDE does, without the ESP32 toolchain.

The IDE auto-generates a prototype for every function in a .ino and hoists them
ABOVE the sketch body.  That is why a type used in a signature has to live in a
header - a struct declared in the .ino itself gives

    error: 'Meas' does not name a type

This script reproduces that hoisting exactly and compiles the result against
minimal Arduino / Wire / WiFi / SSD1306 stubs, so the mistake cannot come back
unnoticed.  It checks C++ correctness, not ESP32 behaviour.

    python3 check_compile.py
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SKETCH = os.path.join(HERE, "..", "firmware", "comp_sensor")
STUB = os.path.join(HERE, "arduino_stub")

PROTO_PATTERNS = (
    r'^(static\s+[A-Za-z_][\w:*&\s]*?\s\*?\w+\s*\([^;{)]*\))\s*\{',
    r'^(void\s+\w+\s*\([^;{)]*\))\s*\{',
)


def check_pio():
    """The two toolchains must keep pointing at the same sources."""
    ini = os.path.join(SKETCH, "..", "platformio.ini")
    if not os.path.exists(ini):
        print("no platformio.ini - Arduino IDE only")
        return True
    txt = open(ini).read()
    m = re.search(r"^\s*src_dir\s*=\s*(\S+)", txt, re.M)
    if not m:
        print("FAIL: platformio.ini has no src_dir, so PlatformIO would build "
              "its own src/ and ignore the sketch")
        return False
    want = os.path.basename(SKETCH.rstrip(os.sep))
    if m.group(1).strip().rstrip("/") != want:
        print("FAIL: platformio.ini src_dir = %s, expected %s - the two "
              "toolchains would build different files" % (m.group(1), want))
        return False
    print("platformio.ini src_dir = %s  (same sources as the Arduino IDE)" % want)
    return True


def main():
    if not shutil.which("g++"):
        print("g++ not found - skipping")
        return 0
    pio_ok = check_pio()
    tmp = tempfile.mkdtemp(prefix="inocheck_")
    for f in os.listdir(STUB):
        shutil.copy(os.path.join(STUB, f), tmp)
    for f in os.listdir(SKETCH):
        if f.endswith((".h", ".ino")):
            shutil.copy(os.path.join(SKETCH, f), tmp)

    src = open(os.path.join(tmp, "comp_sensor.ino")).read()
    protos = []
    for pat in PROTO_PATTERNS:
        protos += [m.group(1).strip() + ";" for m in re.finditer(pat, src, re.M)]
    print("hoisted %d prototypes above the sketch body" % len(protos))

    with open(os.path.join(tmp, "sketch.cpp"), "w") as fh:
        fh.write('#include <Arduino.h>\n#include <Wire.h>\n#include <WiFi.h>\n'
                 '#include <Adafruit_GFX.h>\n#include <Adafruit_SSD1306.h>\n'
                 '#include "config.h"\n#include "calib.h"\n')
        fh.write("\n".join(protos))
        fh.write('\n#line 1 "comp_sensor.ino"\n')
        fh.write(src)

    cmd = ["g++", "-std=gnu++17", "-I", tmp, "-c", "-o", os.devnull,
           "-Wall", "-Wextra", "-Wno-unused-parameter",
           "-Wno-unused-const-variable", os.path.join(tmp, "sketch.cpp")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = (r.stdout + r.stderr).strip()
    if out:
        print(out[:4000])
    ok = r.returncode == 0 and "warning:" not in out and pio_ok
    print("PASS" if ok else "FAIL")
    shutil.rmtree(tmp, ignore_errors=True)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
